import crypto from 'crypto';
import dotenv from 'dotenv';
import express from 'express';
import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';
import worker from './workers/api/src/index';
import { LocalD1Database } from './workers/api/src/localD1';
import { WorkerEnv } from './workers/api/src/types';

dotenv.config();

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const DATA_DIR = path.resolve(__dirname, '.local-data');
const DB_PATH = path.join(DATA_DIR, 'primewirepro.sqlite');
const SECRETS_PATH = path.join(DATA_DIR, 'dev-secrets.json');
const MIGRATIONS_DIR = path.resolve(__dirname, 'workers/migrations');

function getOrCreateDevSecrets(): { sessionSecret: string; bootstrapSecret: string } {
  if (process.env.SESSION_SECRET && process.env.BOOTSTRAP_SETUP_SECRET) {
    return {
      sessionSecret: process.env.SESSION_SECRET,
      bootstrapSecret: process.env.BOOTSTRAP_SETUP_SECRET,
    };
  }
  fs.mkdirSync(DATA_DIR, { recursive: true });
  if (fs.existsSync(SECRETS_PATH)) {
    const existing = JSON.parse(fs.readFileSync(SECRETS_PATH, 'utf8')) as {
      sessionSecret?: string;
      bootstrapSecret?: string;
    };
    if (existing.sessionSecret && existing.bootstrapSecret) {
      return {
        sessionSecret: process.env.SESSION_SECRET ?? existing.sessionSecret,
        bootstrapSecret: process.env.BOOTSTRAP_SETUP_SECRET ?? existing.bootstrapSecret,
      };
    }
  }
  const generated = {
    sessionSecret: process.env.SESSION_SECRET ?? crypto.randomBytes(32).toString('hex'),
    bootstrapSecret: process.env.BOOTSTRAP_SETUP_SECRET ?? crypto.randomBytes(24).toString('hex'),
  };
  fs.writeFileSync(SECRETS_PATH, JSON.stringify(generated, null, 2), { mode: 0o600 });
  return generated;
}

async function startServer() {
  const localDb = new LocalD1Database(DB_PATH);
  localDb.runMigrations(MIGRATIONS_DIR);

  const secrets = getOrCreateDevSecrets();
  const workerEnv: WorkerEnv = {
    DB: localDb,
    SESSION_SECRET: secrets.sessionSecret,
    BOOTSTRAP_SETUP_SECRET: secrets.bootstrapSecret,
    BOOTSTRAP_ADMIN_USERNAME: process.env.BOOTSTRAP_ADMIN_USERNAME,
    BOOTSTRAP_ADMIN_EMAIL: process.env.BOOTSTRAP_ADMIN_EMAIL,
    BOOTSTRAP_ADMIN_PASSWORD: process.env.BOOTSTRAP_ADMIN_PASSWORD,
    PUBLIC_ORIGIN: process.env.PUBLIC_ORIGIN ?? 'https://client.draxwire.shop',
    ADMIN_ORIGIN: process.env.ADMIN_ORIGIN ?? 'https://admin.draxwire.shop',
    ALLOW_LOCAL_DEV_ORIGINS: 'true',
  };

  const app = express();
  app.set('trust proxy', true);

  // Read raw body for /api/* and forward into Cloudflare Worker fetch handler
  app.use('/api', express.raw({ type: '*/*', limit: '1mb' }), async (req, res) => {
    try {
      const originHdr = req.get('origin');
      const refererHdr = req.get('referer');
      const forwardedProto = req.get('x-forwarded-proto')?.split(',')[0]?.trim();
      const host = req.get('x-forwarded-host')?.split(',')[0]?.trim() || req.get('host') || 'localhost:3000';
      const isProxiedHttps =
        forwardedProto === 'https' ||
        Boolean(originHdr?.startsWith('https://')) ||
        Boolean(refererHdr?.startsWith('https://')) ||
        host.endsWith('.run.app') ||
        host.endsWith('.pages.dev') ||
        host.endsWith('.workers.dev');
      const protocol = isProxiedHttps ? 'https' : req.protocol || 'http';
      const fullUrl = `${protocol}://${host}${req.originalUrl}`;

      const headers = new Headers();
      for (const [k, v] of Object.entries(req.headers)) {
        if (typeof v === 'string') headers.set(k, v);
        else if (Array.isArray(v)) headers.set(k, v.join(', '));
      }

      const hasBody = !['GET', 'HEAD'].includes(req.method.toUpperCase());
      const bodyBuffer =
        hasBody && Buffer.isBuffer(req.body) && req.body.length > 0
          ? new Uint8Array(req.body)
          : undefined;

      const webReq = new Request(fullUrl, {
        method: req.method,
        headers,
        body: bodyBuffer,
      });

      const webRes = await worker.fetch(webReq, workerEnv);
      res.status(webRes.status);

      const getSetCookie = (webRes.headers as unknown as { getSetCookie?: () => string[] })
        .getSetCookie;
      const cookies = typeof getSetCookie === 'function' ? getSetCookie.call(webRes.headers) : [];
      webRes.headers.forEach((value, key) => {
        if (key.toLowerCase() !== 'set-cookie') {
          res.setHeader(key, value);
        }
      });
      if (cookies.length > 0) {
        res.setHeader('Set-Cookie', cookies);
      }

      const buf = Buffer.from(await webRes.arrayBuffer());
      res.send(buf);
    } catch (err) {
      res.status(500).json({
        error: err instanceof Error ? err.message : 'Server error',
      });
    }
  });

  const releaseZipPath = path.resolve(__dirname, 'release/primewirepro-cloudflare.zip');
  let releaseBuildPromise: Promise<boolean> | null = null;

  const ensureReleaseArchive = async (): Promise<boolean> => {
    if (fs.existsSync(releaseZipPath)) return true;
    if (!releaseBuildPromise) {
      releaseBuildPromise = (async () => {
        try {
          const { exec } = await import('node:child_process');
          const { promisify } = await import('node:util');
          const execAsync = promisify(exec);
          await execAsync('npm run package:cloudflare', { cwd: __dirname, timeout: 120_000 });
          return fs.existsSync(releaseZipPath);
        } catch {
          return false;
        } finally {
          releaseBuildPromise = null;
        }
      })();
    }
    return releaseBuildPromise;
  };

  app.get('/download/primewirepro-cloudflare.zip', async (_req, res) => {
    const ready = await ensureReleaseArchive();
    if (!ready || !fs.existsSync(releaseZipPath)) {
      res.status(404).json({ error: 'Release archive has not been built yet.' });
      return;
    }
    res.download(releaseZipPath, 'primewirepro-cloudflare.zip');
  });

  app.get('/release-download', async (_req, res) => {
    const exists = await ensureReleaseArchive();
    const sizeKb = exists && fs.existsSync(releaseZipPath)
      ? (fs.statSync(releaseZipPath).size / 1024).toFixed(1)
      : '0';
    res.status(200).type('html').send(`<!doctype html>
<html lang="ar" dir="rtl">
<head>
  <meta charset="utf-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1" />
  <title>تنزيل حزمة 𝐃𝐑𝐀𝐗 𝐓𝐄𝐀𝐌 — Cloudflare</title>
  <style>
    body { margin:0; font-family: system-ui, sans-serif; background:#06070B; color:#f4f4f5; display:flex; min-height:100vh; align-items:center; justify-content:center; padding:20px; }
    .card { max-width:440px; width:100%; background:#0B1020; border:1px solid rgba(59,130,246,0.3); border-radius:20px; padding:24px; text-align:center; box-shadow:0 0 40px rgba(37,99,235,0.16); }
    h1 { font-size:20px; margin:0 0 8px; }
    p { font-size:14px; color:#a1a1aa; line-height:1.6; margin:0 0 20px; }
    a.btn { display:inline-block; width:100%; box-sizing:border-box; padding:14px 18px; border-radius:12px; background:#1d4ed8; color:#fff; font-weight:700; text-decoration:none; font-size:15px; box-shadow:0 0 24px rgba(37,99,235,0.45); }
    .meta { margin-top:14px; font-size:12px; color:#71717a; font-family:monospace; }
  </style>
</head>
<body>
  <div class="card">
    <h1>𝐃𝐑𝐀𝐗 𝐓𝐄𝐀𝐌 — حزمة النشر على Cloudflare</h1>
    <p>ملف ZIP كامل ومنظم يحتوي على الواجهة العامة، لوحة الإدارة، كود Cloudflare Worker، وملفات قاعدة بيانات D1 وتعليمات النشر من الهاتف (بدون أي أسرار).</p>
    ${exists
      ? `<a class="btn" href="/download/primewirepro-cloudflare.zip" download="primewirepro-cloudflare.zip">تنزيل primewirepro-cloudflare.zip (${sizeKb} KB)</a>`
      : `<p>الحزمة غير مبنية بعد. شغّل npm run package:cloudflare.</p>`
    }
    <div class="meta">release/primewirepro-cloudflare.zip</div>
  </div>
</body>
</html>`);
  });

  const isProd = process.env.NODE_ENV === 'production';

  if (!isProd) {
    const { createServer: createViteServer } = await import('vite');
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'custom',
    });

    app.use(vite.middlewares);

    app.use(async (req, res, next) => {
      if (req.originalUrl.startsWith('/api')) return next();
      try {
        const isAdminRoute = req.path === '/admin' || req.path.startsWith('/admin/');
        const templateFile = isAdminRoute ? 'admin.html' : 'index.html';
        let html = fs.readFileSync(path.resolve(__dirname, templateFile), 'utf8');
        html = await vite.transformIndexHtml(req.originalUrl, html);
        res.status(200).set({ 'Content-Type': 'text/html' }).end(html);
      } catch (e) {
        vite.ssrFixStacktrace(e as Error);
        next(e);
      }
    });
  } else {
    const publicDist = path.resolve(__dirname, 'dist');
    const adminDist = path.resolve(__dirname, 'dist-admin');

    app.use('/assets', express.static(path.join(adminDist, 'assets')));
    app.use('/admin', express.static(adminDist));
    app.use(express.static(publicDist));

    app.get('/admin*', (_req, res) => {
      res.sendFile(path.join(adminDist, 'index.html'));
    });

    app.get('*', (_req, res) => {
      res.sendFile(path.join(publicDist, 'index.html'));
    });
  }

  const port = Number(process.env.PORT ?? 3000);
  app.listen(port, '0.0.0.0', () => {
    console.log(`𝐃𝐑𝐀𝐗 𝐓𝐄𝐀𝐌 full-stack server running on http://0.0.0.0:${port}`);
  });
}

startServer().catch((err) => {
  console.error('Failed to start server:', err);
  process.exit(1);
});
