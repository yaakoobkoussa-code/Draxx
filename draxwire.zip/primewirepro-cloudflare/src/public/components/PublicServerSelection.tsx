import React from 'react';
import { motion } from 'motion/react';
import { ArrowLeft, Check, Globe, Lock } from 'lucide-react';
import { UserServer } from '../../shared/types';
import { usePublicAuth } from '../hooks/usePublicAuth';

interface PublicServerSelectionProps {
  onBack: () => void;
}

export const PublicServerSelection: React.FC<PublicServerSelectionProps> = ({ onBack }) => {
  const { userData, selectServer } = usePublicAuth();
  if (!userData) return null;

  const { servers, session, credential } = userData;

  const getStatusMeta = (server: UserServer) => {
    if (!server.enabled || server.status === 'maintenance') {
      return { label: 'Unavailable', className: 'text-rose-400' };
    }
    if (server.status === 'high_load') {
      return { label: 'Elevated Load', className: 'text-amber-400' };
    }
    return { label: 'Operational', className: 'text-emerald-400' };
  };

  return (
    <motion.div
      initial={{ opacity: 0, y: 10 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.2, ease: [0.16, 1, 0.3, 1] }}
      className="space-y-6"
    >
      <div className="flex items-center justify-between gap-4">
        <div className="flex items-center gap-3">
          <button
            type="button"
            onClick={onBack}
            aria-label="Back to dashboard"
            className="min-w-[44px] min-h-[44px] rounded-xl bg-[#111116] hover:bg-white/5 border border-white/10 flex items-center justify-center text-zinc-200 transition-colors"
          >
            <ArrowLeft className="w-5 h-5" />
          </button>
          <div>
            <h1 className="font-display text-xl sm:text-2xl font-bold text-white">
              Server Selection
            </h1>
            <p className="text-xs sm:text-sm text-zinc-400">
              Select from the 5 regional server nodes
            </p>
          </div>
        </div>
        <div className="hidden sm:flex items-center gap-2 text-xs text-zinc-400">
          <Globe className="w-4 h-4 text-blue-400" />
          <span>5 Regional Nodes</span>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
        {servers.map((server) => {
          const isSelected = session.selectedServerId === server.id;
          const isPermitted = credential.allowedServers.includes(server.id);
          const isAvailable = server.enabled && server.status !== 'maintenance';
          const disabled = !isPermitted || !isAvailable;
          const statusMeta = getStatusMeta(server);

          return (
            <motion.button
              key={server.id}
              type="button"
              disabled={disabled}
              whileTap={disabled ? undefined : { scale: 0.985 }}
              onClick={() => selectServer(server.id)}
              className={`relative text-left rounded-2xl p-5 border transition-all min-h-[126px] flex flex-col justify-between ${
                isSelected
                  ? 'bg-[#0B1226] border-blue-500 shadow-[0_0_28px_rgba(37,99,235,0.28)]'
                  : disabled
                  ? 'bg-[#0D0D11] border-white/5 opacity-55 cursor-not-allowed'
                  : 'bg-[#111116] border-white/8 hover:border-blue-500/45 hover:bg-[#101628]'
              }`}
            >
              <div className="flex items-start justify-between gap-3">
                <div className="flex items-center gap-3.5">
                  <span className="text-3xl leading-none select-none" role="img" aria-label={server.name}>
                    {server.flag}
                  </span>
                  <div>
                    <h2 className="font-display text-base font-semibold text-white">
                      {server.name}
                    </h2>
                    <div className="flex items-center gap-2 text-xs text-zinc-400 mt-0.5">
                      <span className="font-mono">{server.code}</span>
                      <span aria-hidden="true">·</span>
                      <span className={statusMeta.className}>{statusMeta.label}</span>
                    </div>
                  </div>
                </div>

                <div
                  className={`w-7 h-7 rounded-full border flex items-center justify-center shrink-0 transition-all ${
                    isSelected
                      ? 'bg-blue-700 border-blue-400 text-white shadow-[0_0_12px_rgba(59,130,246,0.75)]'
                      : !isPermitted
                      ? 'bg-zinc-900 border-white/10 text-zinc-500'
                      : 'bg-[#080808] border-white/15 text-transparent'
                  }`}
                >
                  {!isPermitted ? <Lock className="w-3.5 h-3.5" /> : <Check className="w-4 h-4" />}
                </div>
              </div>

              <div className="mt-4 pt-3 border-t border-white/8 flex items-center justify-between text-xs text-zinc-400">
                <span className="truncate">{server.routingNote}</span>
                <span className="shrink-0 ml-2 text-blue-300">
                  {isSelected ? 'Selected' : !isPermitted ? 'Restricted' : ''}
                </span>
              </div>
            </motion.button>
          );
        })}
      </div>
    </motion.div>
  );
};
