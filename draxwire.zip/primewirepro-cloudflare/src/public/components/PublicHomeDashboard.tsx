import React, { useEffect, useState } from 'react';
import { motion } from 'motion/react';
import {
  AlertTriangle,
  Calendar,
  ChevronRight,
  Clock,
  Copy,
  Eye,
  EyeOff,
  Globe,
  Laptop,
  Loader2,
  Plus,
  Shield,
} from 'lucide-react';
import { Modal } from '../../components/common/Modal';
import { ApiError, apiRequest } from '../../shared/api';
import { useToast } from '../../shared/ToastProvider';
import {
  computeCountdown,
  copyTextToClipboard,
  formatDateTime,
  maskProductKey,
} from '../../utils/formatters';
import { usePublicAuth } from '../hooks/usePublicAuth';

interface PublicHomeDashboardProps {
  onOpenServers: () => void;
}

export const PublicHomeDashboard: React.FC<PublicHomeDashboardProps> = ({
  onOpenServers,
}) => {
  const { userData, refreshUser } = usePublicAuth();
  const { addToast } = useToast();

  const [showKey, setShowKey] = useState(false);
  const [importing, setImporting] = useState(false);
  const [importError, setImportError] = useState<string | null>(null);
  const [missingHappModal, setMissingHappModal] = useState(false);
  const [pendingDeepLink, setPendingDeepLink] = useState<string | null>(null);

  const [countdown, setCountdown] = useState(() =>
    userData
      ? computeCountdown(userData.credential.expiresAt, userData.credential.activatedAt)
      : { days: 0, hours: 0, minutes: 0, seconds: 0, isExpired: false, progressPercent: 0 }
  );

  useEffect(() => {
    if (!userData) return;
    setCountdown(
      computeCountdown(userData.credential.expiresAt, userData.credential.activatedAt)
    );
    const timer = window.setInterval(() => {
      const next = computeCountdown(
        userData.credential.expiresAt,
        userData.credential.activatedAt
      );
      setCountdown(next);
      if (next.isExpired) {
        refreshUser();
      }
    }, 1000);
    return () => window.clearInterval(timer);
  }, [userData, refreshUser]);

  if (!userData) return null;

  const { session, credential, device, servers, features } = userData;
  const currentServer =
    servers.find((s) => s.id === session.selectedServerId) ?? servers[0];
  const currentFeature =
    features.find((f) => f.id === session.activeFeatureId) ?? null;
  const isCurrentServerUnavailable =
    !currentServer.enabled ||
    currentServer.status === 'maintenance' ||
    !credential.allowedServers.includes(currentServer.id);

  const displayedKey = showKey
    ? credential.code
    : session.authType === 'product_key'
    ? maskProductKey(credential.code)
    : `${credential.code.slice(0, 3)}••••`;

  const handleCopyKey = async () => {
    const ok = await copyTextToClipboard(credential.code);
    if (ok) {
      addToast({ type: 'success', title: 'Access code copied' });
    } else {
      addToast({ type: 'info', title: 'Copy unavailable in browser context' });
    }
  };

  // Official Happ Subscription Import — ONE button only (ADD SUBSCRIPTION), NO Copy Link
  const handleAddSubscription = async () => {
    setImportError(null);
    if (!currentFeature) {
      const msg = 'Select AIM POINT or AIM POINT AND MOCO MARK on the Features page first.';
      setImportError(msg);
      addToast({ type: 'warning', title: 'No feature selected', description: msg });
      return;
    }

    setImporting(true);
    try {
      const res = await apiRequest<{
        ok: boolean;
        happDeepLink: string;
      }>('/api/subscription/resolve', {
        method: 'POST',
        scope: 'user',
        body: {
          serverId: currentServer.id,
          featureId: currentFeature.id,
        },
      });

      setPendingDeepLink(res.happDeepLink);

      let appOpened = false;
      const onVisibilityChange = () => {
        if (document.hidden) appOpened = true;
      };
      const onBlur = () => {
        appOpened = true;
      };
      document.addEventListener('visibilitychange', onVisibilityChange);
      window.addEventListener('blur', onBlur);

      window.location.href = res.happDeepLink;

      window.setTimeout(() => {
        document.removeEventListener('visibilitychange', onVisibilityChange);
        window.removeEventListener('blur', onBlur);
        setImporting(false);
        if (!appOpened) {
          setMissingHappModal(true);
        }
      }, 1800);
    } catch (err) {
      setImporting(false);
      const message =
        err instanceof ApiError ? err.message : 'SUBSCRIPTION NOT AVAILABLE';
      setImportError(message);
      addToast({
        type: 'error',
        title: message === 'SUBSCRIPTION NOT AVAILABLE' ? 'SUBSCRIPTION NOT AVAILABLE' : 'Import failed',
        description:
          message === 'SUBSCRIPTION NOT AVAILABLE'
            ? 'This region and feature subscription is currently unavailable or disabled.'
            : message,
      });
    }
  };

  const isExpiringSoon = !countdown.isExpired && countdown.days === 0 && countdown.hours < 2;

  const countdownUnits = [
    { label: 'DAYS', value: String(countdown.days).padStart(2, '0'), highlight: false },
    { label: 'HOURS', value: String(countdown.hours).padStart(2, '0'), highlight: true },
    { label: 'MINS', value: String(countdown.minutes).padStart(2, '0'), highlight: false },
    { label: 'SECS', value: String(countdown.seconds).padStart(2, '0'), highlight: true },
  ];

  return (
    <motion.div
      initial={{ opacity: 0, y: 10 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.2, ease: [0.16, 1, 0.3, 1] }}
      className="space-y-5"
    >
      {/* Elevated Top Server Switcher Bar + Header */}
      <div className="space-y-3">
        <div className="flex flex-wrap items-center justify-between gap-3">
          <span className="text-xs font-medium text-blue-400">
            {session.authType === 'product_key'
              ? 'Individual Product Key · 1-Device Lock'
              : 'Universal Public Access'}
          </span>

          <button
            type="button"
            onClick={onOpenServers}
            className="min-h-[42px] px-3.5 py-2 rounded-xl bg-[#0A1022] hover:bg-blue-500/15 border border-blue-500/35 hover:border-blue-400/70 flex items-center gap-2.5 text-sm font-medium text-white shadow-[0_0_20px_rgba(37,99,235,0.2)] transition-all group"
          >
            <Globe className="w-3.5 h-3.5 text-blue-400 shrink-0" />
            <span className="text-lg leading-none">{currentServer.flag}</span>
            <span>{currentServer.name}</span>
            <span className="text-[11px] font-medium text-blue-300 pl-1 border-l border-white/10">
              Change Server
            </span>
            <ChevronRight className="w-4 h-4 text-blue-300 group-hover:translate-x-0.5 transition-transform" />
          </button>
        </div>

        <div>
          <h1 className="font-display text-2xl sm:text-3xl font-bold tracking-tight text-white text-balance">
            Welcome back to {userData.settings.websiteTitle}
          </h1>
          <p className="mt-1 text-sm text-zinc-400">
            Select your region and feature profile, then import into Happ.
          </p>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-5 items-stretch">
        {/* Enhanced Subscription Countdown Card */}
        <section className="relative overflow-hidden lg:col-span-7 rounded-2xl bg-gradient-to-br from-[#0B1226] via-[#090D1A] to-[#08090F] border border-blue-500/30 p-5 sm:p-6 flex flex-col justify-between shadow-[0_0_40px_rgba(37,99,235,0.16)]">
          <div className="pointer-events-none absolute -top-20 -right-20 w-56 h-56 rounded-full bg-blue-600/16 blur-3xl" />

          <div className="relative z-10">
            <div className="flex items-center justify-between gap-3">
              <div className="flex items-center gap-2 text-xs font-medium text-zinc-300">
                <div className="w-7 h-7 rounded-lg bg-blue-500/15 border border-blue-500/35 flex items-center justify-center">
                  <Clock className="w-3.5 h-3.5 text-blue-300" />
                </div>
                <span>Key Remaining Time</span>
              </div>

              <span
                className={`inline-flex items-center gap-1.5 text-xs font-semibold whitespace-nowrap shrink-0 ${
                  countdown.isExpired
                    ? 'text-rose-400'
                    : isExpiringSoon
                    ? 'text-amber-300'
                    : 'text-emerald-400'
                }`}
              >
                <span
                  className={`w-2 h-2 rounded-full ${
                    countdown.isExpired
                      ? 'bg-rose-400'
                      : isExpiringSoon
                      ? 'bg-amber-400 animate-pulse'
                      : 'bg-emerald-400 animate-pulse'
                  }`}
                />
                {countdown.isExpired ? 'Expired' : isExpiringSoon ? 'Expiring Soon' : 'Active Plan'}
              </span>
            </div>

            <div className="mt-5 grid grid-cols-4 gap-2.5 sm:gap-3.5">
              {countdownUnits.map((unit) => (
                <div
                  key={unit.label}
                  className={`rounded-xl border px-2 py-3.5 sm:py-4 text-center transition-colors ${
                    unit.highlight
                      ? 'bg-blue-950/35 border-blue-500/35 shadow-[inset_0_1px_0_rgba(96,165,250,0.16)]'
                      : 'bg-[#09090D]/90 border-white/8'
                  }`}
                >
                  <div
                    className={`font-display text-2xl sm:text-4xl font-bold tracking-tight tabular-nums leading-none ${
                      countdown.isExpired
                        ? 'text-zinc-500'
                        : unit.highlight
                        ? 'text-blue-300 drop-shadow-[0_0_12px_rgba(59,130,246,0.6)]'
                        : 'text-white'
                    }`}
                  >
                    {unit.value}
                  </div>
                  <div className="mt-2 text-[10px] sm:text-[11px] font-semibold tracking-widest text-zinc-400">
                    {unit.label}
                  </div>
                </div>
              ))}
            </div>
          </div>

          <div className="relative z-10 mt-6">
            <div className="flex items-center justify-between text-[11px] text-zinc-400 mb-2">
              <span>Subscription Validity Window</span>
              <span className="font-mono text-blue-300 tabular-nums">
                {countdown.progressPercent}% remaining
              </span>
            </div>
            <div className="h-2.5 w-full rounded-full bg-white/8 p-0.5 overflow-hidden">
              <div
                className="h-full rounded-full bg-gradient-to-r from-blue-700 via-blue-500 to-sky-400 shadow-[0_0_12px_rgba(59,130,246,0.8)] transition-all duration-500"
                style={{ width: `${countdown.progressPercent}%` }}
              />
            </div>

            <div className="mt-4 pt-4 border-t border-white/8 grid grid-cols-2 sm:grid-cols-3 gap-4 text-xs">
              <div>
                <p className="text-zinc-500 flex items-center gap-1.5">
                  <Calendar className="w-3.5 h-3.5 text-blue-400/75" />
                  <span>Activated</span>
                </p>
                <p className="mt-1 font-medium text-zinc-200 tabular-nums">
                  {formatDateTime(credential.activatedAt)}
                </p>
              </div>
              <div>
                <p className="text-zinc-500 flex items-center gap-1.5">
                  <Calendar className="w-3.5 h-3.5 text-blue-400/75" />
                  <span>Expires</span>
                </p>
                <p className="mt-1 font-medium text-zinc-200 tabular-nums">
                  {formatDateTime(credential.expiresAt)}
                </p>
              </div>
              <div className="col-span-2 sm:col-span-1">
                <p className="text-zinc-500 flex items-center gap-1.5">
                  <Laptop className="w-3.5 h-3.5 text-blue-400/75" />
                  <span>Device Binding</span>
                </p>
                <p className="mt-1 font-medium text-zinc-200 truncate">
                  {device.permanentBinding ? '1-Device Bound' : 'Multi-User Code'}
                </p>
              </div>
            </div>
          </div>
        </section>

        {/* Credential & Happ Subscription Import Column */}
        <div className="lg:col-span-5 flex flex-col gap-5">
          <section className="rounded-2xl bg-[#111116] border border-white/8 p-5">
            <div className="flex items-center justify-between gap-2">
              <span className="text-xs text-zinc-400">
                {session.authType === 'product_key' ? 'Licensed Product Key' : 'Universal Access Code'}
              </span>
              <span className="text-xs text-zinc-400">{device.platform}</span>
            </div>

            <div className="mt-3 flex items-center justify-between gap-2 rounded-xl bg-[#080808] border border-white/8 px-3.5 py-2.5">
              <code className="font-mono text-sm text-zinc-100 tracking-wider truncate">
                {displayedKey}
              </code>
              <div className="flex items-center gap-1 shrink-0">
                <button
                  type="button"
                  onClick={() => setShowKey((v) => !v)}
                  aria-label={showKey ? 'Hide key' : 'Show key'}
                  className="min-w-[40px] min-h-[40px] rounded-lg hover:bg-white/8 text-zinc-400 hover:text-white flex items-center justify-center transition-colors"
                >
                  {showKey ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                </button>
                <button
                  type="button"
                  onClick={handleCopyKey}
                  aria-label="Copy key"
                  className="min-w-[40px] min-h-[40px] rounded-lg hover:bg-blue-500/15 text-zinc-400 hover:text-blue-300 flex items-center justify-center transition-colors"
                >
                  <Copy className="w-4 h-4" />
                </button>
              </div>
            </div>
          </section>

          {/* Happ Subscription Import Card — ONE BUTTON ONLY: ADD SUBSCRIPTION */}
          <section className="flex-1 rounded-2xl bg-[#0A1022] border border-blue-500/35 p-5 flex flex-col justify-between shadow-[0_0_32px_rgba(37,99,235,0.18)]">
            <div>
              <div className="flex items-center gap-2.5">
                <div className="w-9 h-9 rounded-xl bg-blue-600/20 border border-blue-500/45 flex items-center justify-center text-blue-300">
                  <Shield className="w-4 h-4" />
                </div>
                <div>
                  <h2 className="font-display text-base font-semibold text-white">
                    Happ Subscription Import
                  </h2>
                  <p className="text-xs text-zinc-400">Code-bound Happ deep-link authorization</p>
                </div>
              </div>
              <p className="mt-3 text-xs text-zinc-300 leading-relaxed">
                Imports your code-timed configuration for{' '}
                <span className="text-white font-medium">{currentServer.name}</span>
                {currentFeature ? ` · ${currentFeature.title}` : ' (select a feature first)'} —
                automatically stops when your key expires.
              </p>

              {isCurrentServerUnavailable && (
                <div
                  role="alert"
                  className="mt-3 rounded-xl bg-amber-500/10 border border-amber-500/30 px-3 py-2 text-xs text-amber-200 flex items-start gap-2"
                >
                  <AlertTriangle className="w-4 h-4 text-amber-400 shrink-0 mt-0.5" />
                  <span>
                    Selected server ({currentServer.name}) is currently unavailable or restricted.
                    Tap Change Server above to pick an active region.
                  </span>
                </div>
              )}

              {importError && (
                <div
                  role="alert"
                  className="mt-3 rounded-xl bg-rose-500/10 border border-rose-500/30 px-3 py-2 text-xs text-rose-200 flex items-start gap-2"
                >
                  <AlertTriangle className="w-4 h-4 text-rose-400 shrink-0 mt-0.5" />
                  <span>{importError}</span>
                </div>
              )}
            </div>

            <button
              type="button"
              disabled={importing}
              onClick={handleAddSubscription}
              className="mt-4 w-full min-h-[46px] rounded-xl bg-blue-700 hover:bg-blue-600 active:scale-[0.99] disabled:opacity-60 text-sm font-semibold text-white shadow-[0_0_24px_rgba(37,99,235,0.48)] flex items-center justify-center gap-2 transition-all"
            >
              {importing ? (
                <>
                  <Loader2 className="w-4 h-4 animate-spin" />
                  <span>Opening Happ...</span>
                </>
              ) : (
                <>
                  <Plus className="w-4 h-4" />
                  <span>ADD SUBSCRIPTION</span>
                </>
              )}
            </button>
          </section>
        </div>
      </div>

      {/* Missing Happ Installation Fallback Modal */}
      <Modal
        open={missingHappModal}
        onClose={() => setMissingHappModal(false)}
        title="Happ App Not Detected"
        subtitle="Install Happ on your device to complete subscription import"
      >
        <div className="space-y-4 text-sm text-zinc-300">
          <p className="leading-relaxed">
            Your browser did not hand off the <code className="font-mono text-blue-300">happ://</code>{' '}
            deep link to the Happ application. This usually means Happ is not installed on this device or
            deep-link handoff was blocked by your browser.
          </p>
          <div className="rounded-xl bg-[#080808] border border-white/10 p-4 text-xs space-y-2 text-zinc-400">
            <p className="font-semibold text-zinc-200">How to resolve:</p>
            <ol className="list-decimal list-inside space-y-1">
              <li>Install the official Happ Proxy Utility from Google Play, App Store, or happ.su.</li>
              <li>Return to 𝐃𝐑𝐀𝐗 𝐓𝐄𝐀𝐌 in your mobile browser and tap ADD SUBSCRIPTION again.</li>
            </ol>
          </div>
          <div className="flex flex-wrap items-center justify-end gap-2">
            {pendingDeepLink && (
              <a
                href={pendingDeepLink}
                className="min-h-[44px] px-5 rounded-xl bg-white/10 hover:bg-white/15 border border-blue-500/40 text-sm font-semibold text-blue-200 inline-flex items-center justify-center"
              >
                Open Happ App
              </a>
            )}
            <button
              type="button"
              onClick={() => setMissingHappModal(false)}
              className="min-h-[44px] px-5 rounded-xl bg-blue-700 hover:bg-blue-600 text-sm font-semibold text-white"
            >
              Close
            </button>
          </div>
        </div>
      </Modal>
    </motion.div>
  );
};
