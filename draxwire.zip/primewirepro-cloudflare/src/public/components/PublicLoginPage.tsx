import React, { useState } from 'react';
import { motion } from 'motion/react';
import {
  AlertCircle,
  ArrowRight,
  Check,
  ClipboardPaste,
  KeyRound,
  Loader2,
} from 'lucide-react';
import { BrandLogo } from '../../components/common/BrandLogo';
import { useToast } from '../../shared/ToastProvider';
import { formatProductKeyInput } from '../../utils/formatters';
import { usePublicAuth } from '../hooks/usePublicAuth';

export const PublicLoginPage: React.FC = () => {
  const { publicStatus, login } = usePublicAuth();
  const { addToast } = useToast();

  const [codeInput, setCodeInput] = useState('');
  const [rememberDevice, setRememberDevice] = useState(true);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [errorMsg, setErrorMsg] = useState<string | null>(null);

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    setErrorMsg(null);
    const val = e.target.value;
    const upper = val.toUpperCase();
    // Auto-format DRX-XXX-XXX product keys, while allowing alphanumeric Universal Codes
    if (upper.startsWith('DRX') || /^D(R(X)?)?$/.test(upper.replace(/[^A-Z0-9]/g, ''))) {
      setCodeInput(formatProductKeyInput(upper));
    } else {
      setCodeInput(upper.replace(/[^A-Z0-9_-]/g, '').slice(0, 40));
    }
  };

  const handlePaste = async () => {
    setErrorMsg(null);
    try {
      const text = await navigator.clipboard.readText();
      if (text && text.trim()) {
        const upper = text.trim().toUpperCase();
        if (upper.startsWith('DRX')) {
          setCodeInput(formatProductKeyInput(upper));
        } else {
          setCodeInput(upper.replace(/[^A-Z0-9_-]/g, '').slice(0, 40));
        }
        addToast({ type: 'info', title: 'Key pasted from clipboard' });
        return;
      }
      addToast({
        type: 'warning',
        title: 'Clipboard is empty',
        description: 'Copy your key first or type it into the input field.',
      });
    } catch {
      addToast({
        type: 'info',
        title: 'Clipboard access unavailable',
        description: 'Paste your key directly into the field using Ctrl+V or long-press.',
      });
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMsg(null);
    const trimmed = codeInput.trim();
    if (trimmed.length < 4) {
      const msg = 'Enter a valid product key or universal access code.';
      setErrorMsg(msg);
      addToast({ type: 'error', title: 'Invalid input', description: msg });
      return;
    }

    setIsSubmitting(true);
    const res = await login(trimmed, rememberDevice);
    setIsSubmitting(false);

    if (!res.ok && res.error) {
      setErrorMsg(res.error);
      addToast({
        type: 'error',
        title: 'Authentication failed',
        description: res.error,
      });
    }
  };

  return (
    <div className="relative min-h-screen bg-[#080808] text-zinc-100 flex flex-col justify-between overflow-hidden px-4 py-6 pt-safe pb-safe">
      {/* Ambient Background */}
      <div className="pointer-events-none fixed inset-0 overflow-hidden">
        <div className="absolute -top-32 left-1/2 -translate-x-1/2 w-[540px] h-[540px] rounded-full bg-blue-600/20 blur-[120px] animate-ambient" />
        <div className="absolute bottom-[-180px] right-[-100px] w-[420px] h-[420px] rounded-full bg-blue-800/18 blur-[110px]" />
        <div
          className="absolute inset-0 opacity-[0.035]"
          style={{
            backgroundImage:
              'linear-gradient(to right, #ffffff 1px, transparent 1px), linear-gradient(to bottom, #ffffff 1px, transparent 1px)',
            backgroundSize: '48px 48px',
          }}
        />
      </div>

      <div className="relative z-10 w-full max-w-6xl mx-auto flex items-center justify-between">
        <div className="flex items-center gap-2.5">
          <BrandLogo size="sm" glow={false} />
          <span className="font-display text-sm font-semibold tracking-tight text-white">
            {publicStatus?.websiteTitle ?? '𝐃𝐑𝐀𝐗 𝐓𝐄𝐀𝐌'}
          </span>
        </div>
      </div>

      <main className="relative z-10 w-full max-w-md mx-auto my-auto py-8">
        <motion.div
          initial={{ opacity: 0, y: 14 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.25, ease: [0.16, 1, 0.3, 1] }}
          className="rounded-2xl bg-[#0B101E]/95 backdrop-blur-xl border border-blue-500/20 p-6 sm:p-8 shadow-2xl shadow-black/80"
        >
          <div className="flex flex-col items-center text-center">
            <BrandLogo size="xl" glow />
            <h1 className="mt-5 font-display text-2xl font-bold tracking-tight text-white text-balance">
              {publicStatus?.websiteTitle ?? '𝐃𝐑𝐀𝐗 𝐓𝐄𝐀𝐌'}
            </h1>
            <p className="mt-1.5 text-sm text-zinc-400">
              Sign in with your product key or access code.
            </p>
          </div>

          <form onSubmit={handleSubmit} className="mt-6 space-y-5">
            <div>
              <div className="flex items-center justify-between mb-2">
                <label
                  htmlFor="product-key-input"
                  className="text-xs font-medium text-zinc-300"
                >
                  Product Key
                </label>
                <span className="text-[11px] font-mono text-zinc-500">DRX-XXX-XXX</span>
              </div>

              <div className="relative flex items-center">
                <KeyRound className="w-4 h-4 text-zinc-500 absolute left-3.5 pointer-events-none" />
                <input
                  id="product-key-input"
                  type="text"
                  value={codeInput}
                  onChange={handleInputChange}
                  placeholder="DRX-XXX-XXX"
                  autoCapitalize="characters"
                  autoCorrect="off"
                  spellCheck={false}
                  maxLength={40}
                  className="w-full min-h-[48px] pl-10 pr-28 rounded-xl bg-[#080808] border border-white/12 text-[13px] sm:text-sm font-mono tracking-wider text-white placeholder:text-zinc-600 focus:outline-none focus:border-blue-500 focus:ring-2 focus:ring-blue-500/25 transition-all"
                />
                <button
                  type="button"
                  onClick={handlePaste}
                  className="absolute right-1.5 min-h-[38px] px-3 rounded-lg bg-white/5 hover:bg-blue-500/15 border border-white/10 hover:border-blue-500/45 text-xs font-medium text-zinc-200 flex items-center gap-1.5 transition-colors whitespace-nowrap shrink-0"
                >
                  <ClipboardPaste className="w-3.5 h-3.5 text-blue-400" />
                  <span>Paste Key</span>
                </button>
              </div>
            </div>

            {errorMsg && (
              <motion.div
                initial={{ opacity: 0, y: -4 }}
                animate={{ opacity: 1, y: 0 }}
                role="alert"
                className="rounded-xl bg-rose-500/10 border border-rose-500/30 px-3.5 py-2.5 flex items-start gap-2.5 text-xs text-rose-200"
              >
                <AlertCircle className="w-4 h-4 text-rose-400 shrink-0 mt-0.5" />
                <span>{errorMsg}</span>
              </motion.div>
            )}

            <label className="flex items-center justify-between gap-3 cursor-pointer select-none min-h-[44px] px-1">
              <div className="flex items-center gap-3">
                <button
                  type="button"
                  role="checkbox"
                  aria-checked={rememberDevice}
                  onClick={() => setRememberDevice((v) => !v)}
                  className={`w-5 h-5 rounded-md border flex items-center justify-center transition-colors ${
                    rememberDevice
                      ? 'bg-blue-700 border-blue-400 text-white'
                      : 'bg-[#080808] border-white/20 text-transparent'
                  }`}
                >
                  <Check className="w-3.5 h-3.5" />
                </button>
                <span className="text-sm text-zinc-300">Remember this device</span>
              </div>
            </label>

            <button
              type="submit"
              disabled={isSubmitting}
              className="w-full min-h-[48px] rounded-xl bg-blue-700 hover:bg-blue-600 active:scale-[0.99] disabled:opacity-60 disabled:cursor-not-allowed text-sm font-semibold text-white shadow-[0_0_26px_rgba(37,99,235,0.48)] flex items-center justify-center gap-2 transition-all"
            >
              {isSubmitting ? (
                <>
                  <Loader2 className="w-4 h-4 animate-spin" />
                  <span>Verifying access...</span>
                </>
              ) : (
                <>
                  <span>Continue</span>
                  <ArrowRight className="w-4 h-4" />
                </>
              )}
            </button>
          </form>
        </motion.div>
      </main>

      <footer className="relative z-10 w-full max-w-6xl mx-auto text-center text-xs text-zinc-500">
        <span>{publicStatus?.websiteTitle ?? '𝐃𝐑𝐀𝐗 𝐓𝐄𝐀𝐌'}</span>
      </footer>
    </div>
  );
};
