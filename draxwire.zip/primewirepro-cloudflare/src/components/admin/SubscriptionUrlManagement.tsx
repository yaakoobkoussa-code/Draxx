import React, { useEffect, useState } from 'react';
import { Check, Eraser, Link2, Save } from 'lucide-react';
import { useAppState } from '../../hooks/useAppState';
import { formatDateTime } from '../../utils/formatters';

export const SubscriptionUrlManagement: React.FC = () => {
  const { subscriptionUrls, servers, updateSubscriptionUrl } = useAppState();
  const [drafts, setDrafts] = useState<Record<string, string>>({});

  useEffect(() => {
    const next: Record<string, string> = {};
    for (const slot of subscriptionUrls) {
      next[slot.id] = slot.url;
    }
    setDrafts(next);
  }, [subscriptionUrls]);

  const configuredCount = subscriptionUrls.filter((s) => s.url.trim().length > 0).length;

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row sm:items-end justify-between gap-4">
        <div>
          <h1 className="font-display text-2xl font-bold text-white">
            Subscription URL Management
          </h1>
          <p className="text-sm text-zinc-400 mt-0.5">
            Configure the 10 private subscription configuration endpoints (5 server regions × 2
            features). Empty by default until populated by an administrator.
          </p>
        </div>

        <div className="text-xs font-mono text-zinc-300 tabular-nums shrink-0">
          {configuredCount} / 10 Configured
        </div>
      </div>

      {/* Grouped cleanly by the 5 Server Regions, 2 Feature Fields each = 10 total */}
      <div className="space-y-5">
        {servers.map((server) => {
          const regionSlots = subscriptionUrls.filter((s) => s.serverId === server.id);

          return (
            <section
              key={server.id}
              className="rounded-2xl bg-[#101015] border border-zinc-800/90 p-5 space-y-4"
            >
              <div className="flex items-center justify-between gap-2 pb-3 border-b border-zinc-800/80">
                <div className="flex items-center gap-2.5">
                  <span className="text-xl leading-none">{server.flag}</span>
                  <div>
                    <h2 className="font-display text-base font-semibold text-white">
                      {server.name}
                    </h2>
                    <p className="text-xs text-zinc-500 font-mono">{server.code} · 2 Feature Slots</p>
                  </div>
                </div>
              </div>

              <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
                {regionSlots.map((slot) => {
                  const draft = drafts[slot.id] ?? '';
                  const isDirty = draft !== slot.url;
                  const isSaved = slot.url.trim().length > 0 && !isDirty;

                  return (
                    <div
                      key={slot.id}
                      className="rounded-xl bg-[#07070A] border border-zinc-800 p-4 space-y-2.5"
                    >
                      <div className="flex items-center justify-between gap-2">
                        <label
                          htmlFor={`url-${slot.id}`}
                          className="text-xs font-semibold text-zinc-200 flex items-center gap-1.5"
                        >
                          <Link2 className="w-3.5 h-3.5 text-purple-400 shrink-0" />
                          <span>{slot.featureTitle}</span>
                        </label>
                        <span className="text-[11px] text-zinc-500">
                          {slot.url.trim()
                            ? `Updated ${formatDateTime(slot.updatedAt)}`
                            : 'Empty configuration'}
                        </span>
                      </div>

                      <input
                        id={`url-${slot.id}`}
                        type="url"
                        value={draft}
                        onChange={(e) =>
                          setDrafts((prev) => ({ ...prev, [slot.id]: e.target.value }))
                        }
                        placeholder={`Enter private subscription URL for ${slot.serverName} — ${slot.featureTitle}`}
                        className="w-full min-h-[44px] px-3 rounded-xl bg-[#101015] border border-zinc-800 text-xs font-mono text-white placeholder:text-zinc-600 focus:outline-none focus:border-purple-500"
                      />

                      <div className="flex items-center justify-end gap-2">
                        {draft.trim() !== '' && (
                          <button
                            type="button"
                            onClick={() => {
                              setDrafts((prev) => ({ ...prev, [slot.id]: '' }));
                              updateSubscriptionUrl(slot.id, '');
                            }}
                            className="min-h-[36px] px-3 rounded-lg bg-white/5 hover:bg-white/10 text-xs text-zinc-400 hover:text-white inline-flex items-center gap-1.5"
                          >
                            <Eraser className="w-3.5 h-3.5" />
                            <span>Clear</span>
                          </button>
                        )}
                        <button
                          type="button"
                          onClick={() => updateSubscriptionUrl(slot.id, draft)}
                          disabled={!isDirty && !draft.trim()}
                          className={`min-h-[36px] px-3.5 rounded-lg text-xs font-medium inline-flex items-center gap-1.5 transition-colors ${
                            isSaved
                              ? 'bg-emerald-500/15 text-emerald-300 border border-emerald-500/30'
                              : 'bg-purple-600 hover:bg-purple-500 disabled:opacity-40 text-white'
                          }`}
                        >
                          {isSaved ? (
                            <>
                              <Check className="w-3.5 h-3.5" />
                              <span>Saved</span>
                            </>
                          ) : (
                            <>
                              <Save className="w-3.5 h-3.5" />
                              <span>Save Slot</span>
                            </>
                          )}
                        </button>
                      </div>
                    </div>
                  );
                })}
              </div>
            </section>
          );
        })}
      </div>
    </div>
  );
};
