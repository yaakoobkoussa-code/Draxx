import React, { useState } from 'react';
import { motion } from 'motion/react';
import {
  AlertCircle,
  ArrowLeft,
  KeyRound,
  Loader2,
  Lock,
  ShieldCheck,
  UserCheck,
} from 'lucide-react';
import { useAppState } from '../../hooks/useAppState';
import { BrandLogo } from '../common/BrandLogo';

interface AdminLoginPageProps {
  onBackToClient: () => void;
}

export const AdminLoginPage: React.FC<AdminLoginPageProps> = ({ onBackToClient }) => {
  const { loginAdmin, addToast } = useAppState();
  const [username, setUsername] = useState('admin@primewire.pro');
  const [password, setPassword] = useState('demo-admin-2026');
  const [twoFactorCode, setTwoFactorCode] = useState('');
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);
    setLoading(true);
    const res = await loginAdmin(username, password);
    setLoading(false);
    if (!res.ok && res.message) {
      setError(res.message);
      addToast({ type: 'error', title: 'Admin login failed', description: res.message });
    }
  };

  return (
    <div className="min-h-screen bg-[#07070A] text-zinc-100 flex flex-col justify-between px-4 py-6 pt-safe pb-safe">
      <div className="w-full max-w-5xl mx-auto flex items-center justify-between">
        <button
          type="button"
          onClick={onBackToClient}
          className="min-h-[44px] px-3 rounded-xl text-xs font-medium text-zinc-400 hover:text-white hover:bg-white/5 inline-flex items-center gap-2 transition-colors"
        >
          <ArrowLeft className="w-4 h-4" />
          <span>Back to Client App</span>
        </button>
        <span className="text-xs font-mono text-zinc-500">/admin · Phase 1 Preview</span>
      </div>

      <main className="w-full max-w-md mx-auto my-auto py-8">
        <motion.div
          initial={{ opacity: 0, y: 12 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.2 }}
          className="rounded-2xl bg-[#101015] border border-zinc-800 p-6 sm:p-8 shadow-2xl shadow-black/80"
        >
          <div className="flex items-center gap-3.5">
            <BrandLogo size="md" glow={false} />
            <div>
              <div className="flex items-center gap-1.5 text-xs font-medium text-purple-400">
                <ShieldCheck className="w-3.5 h-3.5" />
                <span>Administration Console</span>
              </div>
              <h1 className="font-display text-xl font-bold text-white">PRIME WIRE PRO</h1>
            </div>
          </div>

          <p className="mt-4 text-xs text-zinc-400 leading-relaxed">
            Simulated Phase 1 administrator sign-in. Credentials below are prefilled for visual preview.
          </p>

          <form onSubmit={handleSubmit} className="mt-5 space-y-4">
            <div>
              <label htmlFor="admin-user" className="block text-xs font-medium text-zinc-300 mb-1.5">
                Administrator Identifier
              </label>
              <div className="relative flex items-center">
                <UserCheck className="w-4 h-4 text-zinc-500 absolute left-3.5 pointer-events-none" />
                <input
                  id="admin-user"
                  type="text"
                  value={username}
                  onChange={(e) => setUsername(e.target.value)}
                  className="w-full min-h-[46px] pl-10 pr-3 rounded-xl bg-[#07070A] border border-zinc-800 text-sm text-white focus:outline-none focus:border-purple-500 transition-colors"
                />
              </div>
            </div>

            <div>
              <label htmlFor="admin-pass" className="block text-xs font-medium text-zinc-300 mb-1.5">
                Passphrase
              </label>
              <div className="relative flex items-center">
                <Lock className="w-4 h-4 text-zinc-500 absolute left-3.5 pointer-events-none" />
                <input
                  id="admin-pass"
                  type="password"
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  className="w-full min-h-[46px] pl-10 pr-3 rounded-xl bg-[#07070A] border border-zinc-800 text-sm text-white focus:outline-none focus:border-purple-500 transition-colors"
                />
              </div>
            </div>

            <div>
              <div className="flex items-center justify-between mb-1.5">
                <label htmlFor="admin-2fa" className="text-xs font-medium text-zinc-300">
                  2FA Code (Optional in Demo)
                </label>
                <span className="text-[11px] font-mono text-zinc-500">6 digits</span>
              </div>
              <div className="relative flex items-center">
                <KeyRound className="w-4 h-4 text-zinc-500 absolute left-3.5 pointer-events-none" />
                <input
                  id="admin-2fa"
                  type="text"
                  inputMode="numeric"
                  maxLength={6}
                  value={twoFactorCode}
                  onChange={(e) => setTwoFactorCode(e.target.value.replace(/\D/g, ''))}
                  placeholder="000000"
                  className="w-full min-h-[46px] pl-10 pr-3 rounded-xl bg-[#07070A] border border-zinc-800 text-sm font-mono tracking-widest text-white placeholder:text-zinc-600 focus:outline-none focus:border-purple-500 transition-colors"
                />
              </div>
            </div>

            {error && (
              <div
                role="alert"
                className="rounded-xl bg-rose-500/10 border border-rose-500/30 px-3.5 py-2.5 text-xs text-rose-200 flex items-start gap-2"
              >
                <AlertCircle className="w-4 h-4 text-rose-400 shrink-0 mt-0.5" />
                <span>{error}</span>
              </div>
            )}

            <button
              type="submit"
              disabled={loading}
              className="w-full min-h-[48px] rounded-xl bg-purple-600 hover:bg-purple-500 disabled:opacity-60 text-sm font-semibold text-white flex items-center justify-center gap-2 transition-colors"
            >
              {loading ? (
                <>
                  <Loader2 className="w-4 h-4 animate-spin" />
                  <span>Opening console...</span>
                </>
              ) : (
                <span>Sign In to Admin Console</span>
              )}
            </button>
          </form>
        </motion.div>
      </main>

      <footer className="w-full max-w-5xl mx-auto text-center text-xs text-zinc-600">
        PRIME WIRE PRO Administration · Phase 1 Simulated Auth
      </footer>
    </div>
  );
};
