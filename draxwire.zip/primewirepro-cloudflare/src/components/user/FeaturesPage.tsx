import React from 'react';
import { motion } from 'motion/react';
import { CheckCircle2, Crosshair, Info, Lock, Radar } from 'lucide-react';
import { useAppState } from '../../hooks/useAppState';
import { ToggleSwitch } from '../common/ToggleSwitch';

export const FeaturesPage: React.FC = () => {
  const { features, keys, userSession, toggleUserFeature } = useAppState();
  const activeKey = keys.find((k) => k.id === userSession?.keyRecordId);

  if (!userSession || !activeKey) return null;

  return (
    <motion.div
      initial={{ opacity: 0, y: 10 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.2, ease: [0.16, 1, 0.3, 1] }}
      className="space-y-6"
    >
      <div className="flex flex-col sm:flex-row sm:items-end justify-between gap-3">
        <div>
          <h1 className="font-display text-2xl sm:text-3xl font-bold tracking-tight text-white">
            Features
          </h1>
          <p className="mt-1 text-sm text-zinc-400">
            Select a precision profile. Only one feature can be active at a time.
          </p>
        </div>
        <div className="flex items-center gap-2 text-xs text-zinc-400">
          <Info className="w-4 h-4 text-purple-400 shrink-0" />
          <span>Mutual exclusion enforced</span>
        </div>
      </div>

      {/* EXACTLY TWO FEATURE CARDS: ONLY AIM POINT & AIM POINT AND MOCO MARK */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
        {features.map((feature) => {
          const isActive = userSession.activeFeatureId === feature.id;
          const isKeyAuthorized = activeKey.allowedFeatures.includes(feature.id);
          const isGloballyEnabled = feature.globallyEnabled;
          const canToggle = isKeyAuthorized && isGloballyEnabled;

          const authStatusLabel = !isGloballyEnabled
            ? 'Disabled by Admin'
            : !isKeyAuthorized
            ? 'Not Authorized on Key'
            : 'Authorized';

          const Icon = feature.id === 'only_aim_point' ? Crosshair : Radar;

          return (
            <div
              key={feature.id}
              className={`rounded-2xl p-6 border transition-all flex flex-col justify-between gap-6 ${
                isActive
                  ? 'bg-[#15111E] border-purple-500 shadow-[0_0_32px_rgba(168,85,247,0.2)]'
                  : 'bg-[#111116] border-white/8'
              }`}
            >
              <div>
                <div className="flex items-start justify-between gap-4">
                  <div className="flex items-center gap-3.5">
                    <div
                      className={`w-12 h-12 rounded-xl border flex items-center justify-center shrink-0 transition-colors ${
                        isActive
                          ? 'bg-purple-600/20 border-purple-400/50 text-purple-300'
                          : 'bg-[#080808] border-white/10 text-zinc-400'
                      }`}
                    >
                      <Icon className="w-5 h-5" />
                    </div>
                    <div>
                      <h2 className="font-display text-lg font-bold tracking-tight text-white">
                        {feature.title}
                      </h2>
                      <div className="mt-1 flex items-center gap-2 text-xs">
                        <span
                          className={
                            isActive ? 'text-purple-400 font-semibold' : 'text-zinc-500 font-medium'
                          }
                        >
                          {isActive ? 'Active' : 'Inactive'}
                        </span>
                        <span aria-hidden="true" className="text-zinc-600">
                          ·
                        </span>
                        <span
                          className={`inline-flex items-center gap-1 ${
                            canToggle ? 'text-emerald-400' : 'text-amber-400'
                          }`}
                        >
                          {canToggle ? (
                            <CheckCircle2 className="w-3.5 h-3.5" />
                          ) : (
                            <Lock className="w-3.5 h-3.5" />
                          )}
                          <span>{authStatusLabel}</span>
                        </span>
                      </div>
                    </div>
                  </div>

                  <ToggleSwitch
                    checked={isActive}
                    disabled={!canToggle}
                    label={`Toggle ${feature.title}`}
                    onChange={() => toggleUserFeature(feature.id)}
                  />
                </div>

                <p className="mt-4 text-sm text-zinc-400 leading-relaxed">{feature.description}</p>
              </div>

              <div className="pt-4 border-t border-white/8 flex items-center justify-between text-xs">
                <span className="text-zinc-500">
                  {isActive
                    ? 'Currently active profile'
                    : canToggle
                    ? 'Tap switch to activate'
                    : 'Unavailable for current session'}
                </span>
                <button
                  type="button"
                  disabled={!canToggle}
                  onClick={() => toggleUserFeature(feature.id)}
                  className={`min-h-[36px] px-3.5 rounded-lg font-medium transition-colors ${
                    !canToggle
                      ? 'bg-white/5 text-zinc-600 cursor-not-allowed'
                      : isActive
                      ? 'bg-white/8 hover:bg-white/12 text-zinc-200'
                      : 'bg-purple-600/20 hover:bg-purple-600/30 text-purple-300 border border-purple-500/30'
                  }`}
                >
                  {isActive ? 'Deactivate' : 'Activate'}
                </button>
              </div>
            </div>
          );
        })}
      </div>
    </motion.div>
  );
};
