import React from 'react';
import { motion } from 'motion/react';
import { Crosshair, Home, LogOut, ShieldCheck, User } from 'lucide-react';
import { useAppState } from '../../hooks/useAppState';
import { UserTab } from '../../types';
import { BrandLogo } from '../common/BrandLogo';

interface UserShellProps {
  activeTab: UserTab;
  onSelectTab: (tab: UserTab) => void;
  onNavigateAdmin: () => void;
  children: React.ReactNode;
}

const NAV_ITEMS: { id: UserTab; label: string; icon: React.ComponentType<{ className?: string }> }[] = [
  { id: 'home', label: 'HOME', icon: Home },
  { id: 'features', label: 'FEATURES', icon: Crosshair },
  { id: 'account', label: 'ACCOUNT', icon: User },
];

export const UserShell: React.FC<UserShellProps> = ({
  activeTab,
  onSelectTab,
  onNavigateAdmin,
  children,
}) => {
  const { settings, logoutUser } = useAppState();

  return (
    <div className="min-h-screen bg-[#080808] text-zinc-100 flex flex-col">
      {/* Ambient top glow */}
      <div className="pointer-events-none fixed inset-x-0 top-0 h-72 bg-gradient-to-b from-purple-900/12 via-purple-950/5 to-transparent" />

      {/* Top Header (Responsive Mobile + Desktop 3-Zone Contract) */}
      <header className="sticky top-0 z-30 bg-[#080808]/90 backdrop-blur-md border-b border-white/8 pt-safe">
        <div className="max-w-6xl mx-auto px-4 sm:px-6 h-14 flex items-center justify-between gap-4 sm:gap-8">
          {/* Zone 1: Brand */}
          <button
            type="button"
            onClick={() => onSelectTab('home')}
            className="flex items-center gap-2.5 whitespace-nowrap shrink-0 text-left focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-purple-500 rounded-lg"
          >
            <BrandLogo size="sm" glow={false} />
            <span className="font-display text-base font-bold tracking-tight text-white">
              {settings.websiteTitle}
            </span>
          </button>

          {/* Zone 2: Desktop Nav (Exactly 3 items) */}
          <nav
            aria-label="Primary navigation"
            className="hidden md:flex items-center gap-6"
          >
            {NAV_ITEMS.map((item) => {
              const Icon = item.icon;
              const isActive = activeTab === item.id;
              return (
                <button
                  key={item.id}
                  type="button"
                  onClick={() => onSelectTab(item.id)}
                  className={`relative min-h-[40px] px-2 flex items-center gap-2 text-xs font-semibold tracking-wide whitespace-nowrap shrink-0 transition-colors ${
                    isActive ? 'text-purple-400' : 'text-zinc-400 hover:text-zinc-100'
                  }`}
                >
                  <Icon className="w-4 h-4" />
                  <span>{item.label}</span>
                  {isActive && (
                    <motion.span
                      layoutId="desktop-nav-indicator"
                      transition={{ type: 'spring', stiffness: 420, damping: 32 }}
                      className="absolute inset-x-0 -bottom-[9px] h-[2px] bg-purple-500 shadow-[0_0_10px_rgba(168,85,247,0.8)]"
                    />
                  )}
                </button>
              );
            })}
          </nav>

          {/* Zone 3: Single Primary Contextual Action */}
          <div className="flex items-center gap-2 shrink-0">
            <button
              type="button"
              onClick={onNavigateAdmin}
              className="hidden sm:inline-flex min-h-[38px] px-3 rounded-lg text-xs font-medium text-zinc-400 hover:text-zinc-100 hover:bg-white/5 items-center gap-1.5 whitespace-nowrap shrink-0 transition-colors"
            >
              <ShieldCheck className="w-3.5 h-3.5 text-purple-400" />
              <span>Admin</span>
            </button>
            <button
              type="button"
              onClick={logoutUser}
              className="min-h-[38px] px-3 rounded-lg bg-white/5 hover:bg-white/10 border border-white/10 text-xs font-medium text-zinc-200 inline-flex items-center gap-1.5 whitespace-nowrap shrink-0 transition-colors"
            >
              <LogOut className="w-3.5 h-3.5 text-zinc-400" />
              <span>Sign Out</span>
            </button>
          </div>
        </div>
      </header>

      {/* Optional System Announcement */}
      {settings.systemMessage.trim() !== '' && (
        <div className="relative z-10 border-b border-purple-500/20 bg-purple-950/20">
          <div className="max-w-6xl mx-auto px-4 sm:px-6 py-2 text-xs text-purple-200/90 flex items-center justify-between gap-4">
            <span className="truncate">{settings.systemMessage}</span>
            <span className="text-[11px] text-purple-300/80 whitespace-nowrap shrink-0">
              Preview Mode
            </span>
          </div>
        </div>
      )}

      {/* Main Content Viewport */}
      <main className="relative z-10 flex-1 w-full max-w-6xl mx-auto px-4 sm:px-6 py-6 pb-24 md:pb-10">
        {children}
      </main>

      {/* Mobile Fixed Bottom Navigation — EXACTLY THREE ITEMS (HOME, FEATURES, ACCOUNT) */}
      <nav
        aria-label="Bottom navigation"
        className="md:hidden fixed bottom-0 left-0 right-0 z-40 bg-[#0D0D11]/95 backdrop-blur-xl border-t border-white/10 pb-safe"
      >
        <div className="grid grid-cols-3 h-16 max-w-lg mx-auto px-2">
          {NAV_ITEMS.map((item) => {
            const Icon = item.icon;
            const isActive = activeTab === item.id;
            return (
              <button
                key={item.id}
                type="button"
                onClick={() => onSelectTab(item.id)}
                className={`relative flex flex-col items-center justify-center min-h-[48px] transition-colors ${
                  isActive ? 'text-purple-400' : 'text-zinc-500 hover:text-zinc-300'
                }`}
              >
                {isActive && (
                  <motion.span
                    layoutId="mobile-nav-indicator"
                    transition={{ type: 'spring', stiffness: 450, damping: 34 }}
                    className="absolute top-0 w-10 h-0.5 rounded-full bg-purple-500 shadow-[0_0_12px_rgba(168,85,247,0.9)]"
                  />
                )}
                <Icon className="w-5 h-5" />
                <span className="mt-1 text-[10px] font-semibold tracking-wider">{item.label}</span>
              </button>
            );
          })}
        </div>
      </nav>
    </div>
  );
};
