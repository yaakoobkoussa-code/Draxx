import React, { useState } from 'react';
import { Shield } from 'lucide-react';

const OFFICIAL_LOGO_PATH =
  '/assets/aistudio/file_00000000d47882108bc5e287e1c846e0_24d794ab.png';

interface BrandLogoProps {
  size?: 'sm' | 'md' | 'lg' | 'xl';
  glow?: boolean;
  className?: string;
}

const SIZE_MAP = {
  sm: 'w-8 h-8 rounded-lg',
  md: 'w-10 h-10 rounded-xl',
  lg: 'w-16 h-16 rounded-2xl',
  xl: 'w-20 h-20 rounded-2xl',
};

export const BrandLogo: React.FC<BrandLogoProps> = ({
  size = 'md',
  glow = true,
  className = '',
}) => {
  const [failed, setFailed] = useState(false);

  return (
    <div
      className={`relative inline-flex items-center justify-center shrink-0 overflow-hidden bg-[#090D1A] border border-blue-500/40 ${
        glow ? 'shadow-[0_0_26px_rgba(37,99,235,0.42)]' : ''
      } ${SIZE_MAP[size]} ${className}`}
    >
      {!failed ? (
        <img
          src={OFFICIAL_LOGO_PATH}
          alt="𝐃𝐑𝐀𝐗 𝐓𝐄𝐀𝐌 logo"
          referrerPolicy="no-referrer"
          onError={() => setFailed(true)}
          className="w-full h-full object-cover"
        />
      ) : (
        <Shield className="w-1/2 h-1/2 text-blue-400" />
      )}
    </div>
  );
};
