export type ServerId = 'brazil' | 'india' | 'singapore' | 'europe' | 'bangladesh';
export type FeatureId = 'aim_point' | 'aim_point_moco_mark';
export type CredentialStatus = 'active' | 'suspended' | 'revoked' | 'expired';
export type AdminRoleId = 'SUPER_ADMIN' | 'ADMIN' | 'SUPPORT' | 'VIEW_ONLY';

export interface PublicStatusResponse {
  websiteTitle: string;
  maintenanceMode: boolean;
  maintenanceMessage: string;
  announcement: string;
  defaultServerId: ServerId;
}

export interface UserServer {
  id: ServerId;
  name: string;
  flag: string;
  code: string;
  enabled: boolean;
  status: 'operational' | 'high_load' | 'maintenance';
  routingNote: string;
}

export interface UserFeature {
  id: FeatureId;
  title: string;
  description: string;
  enabled: boolean;
}

export interface UserMeResponse {
  session: {
    id: string;
    authType: 'product_key' | 'universal_code';
    selectedServerId: ServerId;
    activeFeatureId: FeatureId | null;
    signedInAt: string;
    expiresAt: string;
  };
  credential: {
    code: string;
    status: CredentialStatus;
    durationSeconds: number;
    activatedAt: string | null;
    expiresAt: string;
    allowedServers: ServerId[];
    allowedFeatures: FeatureId[];
  };
  device: {
    id: string;
    label: string;
    platform: string;
    permanentBinding: boolean;
  };
  servers: UserServer[];
  features: UserFeature[];
  settings: {
    websiteTitle: string;
    announcement: string;
  };
}

export interface AdminUser {
  id: string;
  username: string;
  email: string;
  roleId: AdminRoleId;
  permissions: string[];
}

export interface ToastItem {
  id: string;
  type: 'success' | 'error' | 'info' | 'warning';
  title: string;
  description?: string;
}
