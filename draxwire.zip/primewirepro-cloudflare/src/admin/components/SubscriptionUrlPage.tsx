import React, { useCallback, useEffect, useMemo, useRef, useState } from 'react';
import {
  Activity,
  AlertTriangle,
  CheckCircle2,
  Link2,
  RefreshCw,
  Save,
  Trash2,
} from 'lucide-react';
import { ToggleSwitch } from '../../components/common/ToggleSwitch';
import { ApiError, apiRequest } from '../../shared/api';
import { useToast } from '../../shared/ToastProvider';
import { FeatureId, ServerId } from '../../shared/types';
import { formatDateTime } from '../../utils/formatters';

interface SubscriptionUrlRow {
  id: string;
  server_id: ServerId;
  feature_id: FeatureId;
  url: string;
  enabled: number;
  updated_at: string | null;
  updated_by_admin_id: string | null;
  last_tested_at: string | null;
  last_test_status: string | null;
  server_name: string;
  server_flag: string;
  feature_title: string;
}

export const SubscriptionUrlPage: React.FC = () => {
  const { addToast } = useToast();

  const [rows, setRows] = useState<SubscriptionUrlRow[]>([]);
  const [draftUrls, setDraftUrls] = useState<Record<string, string>>({});
  const [loading, setLoading] = useState(true);
  const [busyId, setBusyId] = useState<string | null>(null);
  const [savingAll, setSavingAll] = useState(false);
  const [testingId, setTestingId] = useState<string | null>(null);
  const prevServerMapRef = useRef<Record<string, string>>({});

  const loadUrls = useCallback(
    async (savedSlotIds?: string[]) => {
      setLoading(true);
      try {
        const res = await apiRequest<{ urls: SubscriptionUrlRow[] }>('/api/admin/subscription-urls', {
          scope: 'admin',
        });
        setRows(res.urls);
        setDraftUrls((prevDrafts) => {
          const next: Record<string, string> = {};
          const prevServer = prevServerMapRef.current;
          for (const r of res.urls) {
            const serverUrl = r.url ?? '';
            const wasDirty =
              r.id in prevDrafts &&
              prevDrafts[r.id].trim() !== (prevServer[r.id] ?? '').trim() &&
              !(savedSlotIds ?? []).includes(r.id);
            next[r.id] = wasDirty ? prevDrafts[r.id] : serverUrl;
          }
          return next;
        });
        const newServerMap: Record<string, string> = {};
        for (const r of res.urls) {
          newServerMap[r.id] = r.url ?? '';
        }
        prevServerMapRef.current = newServerMap;
      } catch (err) {
        addToast({
          type: 'error',
          title: 'Failed to load subscription URLs',
          description: err instanceof ApiError ? err.message : undefined,
        });
      } finally {
        setLoading(false);
      }
    },
    [addToast]
  );

  useEffect(() => {
    loadUrls();
  }, [loadUrls]);

  const groupedByServer = useMemo(() => {
    const map = new Map<
      ServerId,
      { serverName: string; serverFlag: string; slots: SubscriptionUrlRow[] }
    >();
    for (const row of rows) {
      const existing = map.get(row.server_id);
      if (existing) {
        existing.slots.push(row);
      } else {
        map.set(row.server_id, {
          serverName: row.server_name,
          serverFlag: row.server_flag,
          slots: [row],
        });
      }
    }
    return Array.from(map.entries());
  }, [rows]);

  const configuredCount = rows.filter((r) => Boolean(r.url?.trim())).length;
  const enabledCount = rows.filter((r) => r.enabled === 1 && Boolean(r.url?.trim())).length;

  const dirtySlots = useMemo(
    () =>
      rows.filter((r) => (draftUrls[r.id] ?? '').trim() !== (r.url ?? '').trim()),
    [rows, draftUrls]
  );

  const handleSaveSlot = async (slot: SubscriptionUrlRow, nextUrlOverride?: string) => {
    const urlToSave = (
      nextUrlOverride !== undefined ? nextUrlOverride : draftUrls[slot.id] ?? ''
    ).trim();
    const wasEmpty = !(slot.url ?? '').trim();
    const nextEnabled = urlToSave ? (wasEmpty ? true : slot.enabled === 1) : false;

    setBusyId(slot.id);
    try {
      await apiRequest(`/api/admin/subscription-urls/${slot.id}`, {
        method: 'PATCH',
        scope: 'admin',
        body: {
          url: urlToSave,
          enabled: nextEnabled,
        },
      });
      addToast({
        type: 'success',
        title: urlToSave
          ? wasEmpty
            ? 'Subscription URL saved & enabled'
            : 'Subscription URL saved'
          : 'Subscription URL cleared',
        description: `${slot.server_name} · ${slot.feature_title}`,
      });
      await loadUrls([slot.id]);
    } catch (err) {
      addToast({
        type: 'error',
        title: 'Could not save URL',
        description: err instanceof ApiError ? err.message : undefined,
      });
    } finally {
      setBusyId(null);
    }
  };

  const handleSaveAllModified = async () => {
    if (dirtySlots.length === 0 || savingAll) return;
    setSavingAll(true);
    const savedIds: string[] = [];
    let failedCount = 0;

    for (const slot of dirtySlots) {
      const urlToSave = (draftUrls[slot.id] ?? '').trim();
      const wasEmpty = !(slot.url ?? '').trim();
      const nextEnabled = urlToSave ? (wasEmpty ? true : slot.enabled === 1) : false;
      try {
        await apiRequest(`/api/admin/subscription-urls/${slot.id}`, {
          method: 'PATCH',
          scope: 'admin',
          body: {
            url: urlToSave,
            enabled: nextEnabled,
          },
        });
        savedIds.push(slot.id);
      } catch {
        failedCount += 1;
      }
    }

    setSavingAll(false);
    await loadUrls(savedIds);
    addToast({
      type: failedCount > 0 ? 'warning' : 'success',
      title:
        failedCount > 0
          ? `Saved ${savedIds.length} URL(s), ${failedCount} failed`
          : `Saved & activated ${savedIds.length} subscription URL(s)`,
    });
  };

  const handleToggleSlot = async (slot: SubscriptionUrlRow) => {
    const draftUrl = (draftUrls[slot.id] ?? slot.url ?? '').trim();
    if (slot.enabled !== 1 && !draftUrl) {
      addToast({
        type: 'warning',
        title: 'URL required before enabling',
        description: 'Enter and save a valid https:// or happ:// subscription URL first.',
      });
      return;
    }

    setBusyId(slot.id);
    try {
      const targetEnabled = slot.enabled !== 1;
      await apiRequest(`/api/admin/subscription-urls/${slot.id}`, {
        method: 'PATCH',
        scope: 'admin',
        body: {
          url: draftUrl,
          enabled: targetEnabled,
        },
      });
      addToast({
        type: 'success',
        title: targetEnabled ? 'Slot enabled' : 'Slot disabled',
        description: `${slot.server_name} · ${slot.feature_title}`,
      });
      await loadUrls([slot.id]);
    } catch (err) {
      addToast({
        type: 'error',
        title: 'Failed to update slot state',
        description: err instanceof ApiError ? err.message : undefined,
      });
    } finally {
      setBusyId(null);
    }
  };

  const handleTestSlot = async (slot: SubscriptionUrlRow) => {
    const draftUrl = (draftUrls[slot.id] ?? '').trim();
    if (draftUrl !== (slot.url ?? '').trim()) {
      addToast({
        type: 'info',
        title: 'Save changes before testing',
        description: 'Save the edited URL first so the availability check tests the stored URL.',
      });
      return;
    }
    setTestingId(slot.id);
    try {
      const res = await apiRequest<{ ok: boolean; status: string; message?: string }>(
        `/api/admin/subscription-urls/${slot.id}/test`,
        {
          method: 'POST',
          scope: 'admin',
        }
      );
      addToast({
        type: res.ok ? 'success' : 'warning',
        title: `Test result: ${res.status}`,
        description: `${slot.server_name} · ${slot.feature_title}`,
      });
      await loadUrls();
    } catch (err) {
      addToast({
        type: 'error',
        title: 'Availability test failed',
        description: err instanceof ApiError ? err.message : undefined,
      });
    } finally {
      setTestingId(null);
    }
  };

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row sm:items-end justify-between gap-3">
        <div>
          <h1 className="font-display text-2xl font-bold text-white">
            Subscription URL Management
          </h1>
          <p className="text-sm text-zinc-400 mt-0.5">
            Manage the 10 Happ subscription endpoints (5 server regions × 2 authorized features).
          </p>
        </div>

        <div className="flex items-center gap-2 self-start sm:self-auto">
          {dirtySlots.length > 0 && (
            <button
              type="button"
              disabled={savingAll}
              onClick={handleSaveAllModified}
              className="min-h-[40px] px-4 rounded-xl bg-blue-700 hover:bg-blue-600 disabled:opacity-50 text-xs font-semibold text-white shadow-[0_0_20px_rgba(37,99,235,0.4)] inline-flex items-center gap-2 transition-colors"
            >
              <Save className="w-3.5 h-3.5" />
              <span>{savingAll ? 'Saving...' : `Save All Modified (${dirtySlots.length})`}</span>
            </button>
          )}
          <button
            type="button"
            onClick={() => loadUrls()}
            className="min-h-[40px] px-3.5 rounded-xl bg-white/5 hover:bg-white/10 border border-zinc-800 text-xs font-medium text-zinc-200 inline-flex items-center gap-2"
          >
            <RefreshCw className={`w-3.5 h-3.5 ${loading ? 'animate-spin' : ''}`} />
            <span>Refresh</span>
          </button>
        </div>
      </div>

      <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
        <div className="rounded-2xl bg-[#101015] border border-zinc-800/90 p-4">
          <p className="text-xs text-zinc-400">Total Slots</p>
          <p className="mt-2 font-display text-2xl font-bold text-white tabular-nums">
            {rows.length} / 10
          </p>
        </div>
        <div className="rounded-2xl bg-[#101015] border border-zinc-800/90 p-4">
          <p className="text-xs text-zinc-400">Configured URLs</p>
          <p className="mt-2 font-display text-2xl font-bold text-blue-300 tabular-nums">
            {configuredCount} / 10
          </p>
        </div>
        <div className="rounded-2xl bg-[#101015] border border-zinc-800/90 p-4">
          <p className="text-xs text-zinc-400">Enabled for Users</p>
          <p className="mt-2 font-display text-2xl font-bold text-emerald-400 tabular-nums">
            {enabledCount} / 10
          </p>
        </div>
      </div>

      <div className="rounded-2xl bg-blue-950/25 border border-blue-500/30 p-4 text-xs text-blue-100/90 leading-relaxed">
        Newly saved <span className="font-mono text-white">https://</span> or direct node URI (
        <span className="font-mono text-white">vless://</span>,{' '}
        <span className="font-mono text-white">trojan://</span>,{' '}
        <span className="font-mono text-white">vmess://</span>) links are automatically wrapped in
        a timed <span className="font-mono text-white">/api/sub/…</span> proxy so a 1-hour key
        subscription runs for exactly 1 hour and stops automatically on expiry. (Encrypted{' '}
        <span className="font-mono text-amber-300">happ://crypt…</span> links cannot be cut off
        remotely.)
      </div>

      {loading && rows.length === 0 ? (
        <p className="text-sm text-zinc-400">Loading subscription slots...</p>
      ) : (
        <div className="space-y-5">
          {groupedByServer.map(([serverId, group]) => (
            <section
              key={serverId}
              className="rounded-2xl bg-[#101015] border border-zinc-800/90 p-5 space-y-4"
            >
              <div className="flex items-center gap-2.5 pb-3 border-b border-zinc-800/80">
                <span className="text-xl">{group.serverFlag}</span>
                <h2 className="font-display text-base font-semibold text-white">
                  {group.serverName}
                </h2>
                <span className="text-[11px] font-mono text-zinc-500 uppercase">{serverId}</span>
              </div>

              <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
                {group.slots.map((slot) => {
                  const draft = draftUrls[slot.id] ?? '';
                  const trimmedDraft = draft.trim();
                  const dirty = trimmedDraft !== (slot.url ?? '').trim();
                  const isBusy = busyId === slot.id || savingAll;
                  const isTesting = testingId === slot.id;
                  const isEnabled = slot.enabled === 1 && Boolean(slot.url?.trim());
                  const isTimedProxy =
                    /^https?:\/\//i.test(trimmedDraft) ||
                    /^happ:\/\/add\/https?:\/\//i.test(trimmedDraft) ||
                    /^(happ:\/\/add\/)?(vless|vmess|trojan|ss|ssr|hysteria2|hy2|hysteria|tuic|wireguard|wg):\/\//i.test(
                      trimmedDraft
                    );
                  const isOpaqueHapp = Boolean(trimmedDraft) && !isTimedProxy && /^happ:\/\//i.test(trimmedDraft);

                  return (
                    <div
                      key={slot.id}
                      className="rounded-xl bg-[#07070A] border border-zinc-800/90 p-4 space-y-3"
                    >
                      <div className="flex items-start justify-between gap-3">
                        <div className="min-w-0">
                          <div className="flex items-center gap-2">
                            <Link2 className="w-3.5 h-3.5 text-blue-400 shrink-0" />
                            <h3 className="text-xs font-semibold text-white truncate">
                              {slot.feature_title}
                            </h3>
                          </div>
                          <p className="text-[11px] font-mono text-zinc-500 mt-0.5">{slot.id}</p>
                        </div>

                        <ToggleSwitch
                          checked={isEnabled}
                          disabled={isBusy}
                          label={`Toggle ${slot.server_name} ${slot.feature_title}`}
                          onChange={() => handleToggleSlot(slot)}
                        />
                      </div>

                      <div>
                        <div className="flex items-center justify-between gap-2 mb-1">
                          <label
                            htmlFor={`sub-url-${slot.id}`}
                            className="block text-[11px] text-zinc-400"
                          >
                            Happ / Subscription Endpoint URL
                          </label>
                          {isTimedProxy && (
                            <span className="text-[10px] font-medium text-blue-300">
                              Code-Timed Auto-Stop
                            </span>
                          )}
                          {isOpaqueHapp && (
                            <span className="text-[10px] font-medium text-amber-300">
                              Encrypted happ:// (No Auto-Stop)
                            </span>
                          )}
                        </div>
                        <input
                          id={`sub-url-${slot.id}`}
                          type="text"
                          value={draft}
                          onChange={(e) =>
                            setDraftUrls((prev) => ({ ...prev, [slot.id]: e.target.value }))
                          }
                          placeholder="https://... or vless://... or happ://..."
                          className="w-full h-10 px-3 rounded-xl bg-[#101015] border border-zinc-800 text-xs font-mono text-zinc-100 placeholder:text-zinc-600 focus:outline-none focus:border-blue-500"
                        />
                      </div>

                      <div className="flex flex-wrap items-center justify-between gap-2 text-[11px] text-zinc-500">
                        <div className="flex items-center gap-1.5 min-w-0">
                          {slot.url?.trim() ? (
                            isEnabled ? (
                              <span className="inline-flex items-center gap-1 text-emerald-400">
                                <CheckCircle2 className="w-3.5 h-3.5" />
                                Active
                              </span>
                            ) : (
                              <span className="inline-flex items-center gap-1 text-amber-400">
                                <AlertTriangle className="w-3.5 h-3.5" />
                                Saved (Disabled)
                              </span>
                            )
                          ) : (
                            <span className="text-zinc-500">Empty slot</span>
                          )}
                          {slot.last_test_status && (
                            <span className="text-zinc-400 truncate">
                              · Test: {slot.last_test_status}
                            </span>
                          )}
                        </div>
                        <span className="tabular-nums">
                          {slot.updated_at ? formatDateTime(slot.updated_at) : 'Never edited'}
                        </span>
                      </div>

                      <div className="flex flex-wrap items-center gap-2 pt-1">
                        <button
                          type="button"
                          disabled={isBusy || (!dirty && Boolean(slot.url))}
                          onClick={() => handleSaveSlot(slot)}
                          className="min-h-[36px] px-3 rounded-xl bg-blue-700 hover:bg-blue-600 disabled:opacity-45 text-xs font-semibold text-white inline-flex items-center gap-1.5 transition-colors shadow-[0_0_16px_rgba(37,99,235,0.3)]"
                        >
                          <Save className="w-3.5 h-3.5" />
                          <span>{isBusy ? 'Saving...' : 'Save URL'}</span>
                        </button>

                        <button
                          type="button"
                          disabled={isTesting || !slot.url?.trim()}
                          onClick={() => handleTestSlot(slot)}
                          className="min-h-[36px] px-3 rounded-xl bg-white/5 hover:bg-white/10 disabled:opacity-40 border border-zinc-800 text-xs font-medium text-zinc-200 inline-flex items-center gap-1.5 transition-colors"
                        >
                          <Activity className={`w-3.5 h-3.5 ${isTesting ? 'animate-pulse' : ''}`} />
                          <span>{isTesting ? 'Testing...' : 'Test Availability'}</span>
                        </button>

                        {slot.url?.trim() && (
                          <button
                            type="button"
                            disabled={isBusy}
                            onClick={() => handleSaveSlot(slot, '')}
                            className="min-h-[36px] px-2.5 rounded-xl bg-rose-500/10 hover:bg-rose-500/20 border border-rose-500/20 text-xs font-medium text-rose-300 inline-flex items-center gap-1 ml-auto transition-colors"
                          >
                            <Trash2 className="w-3.5 h-3.5" />
                            <span>Clear</span>
                          </button>
                        )}
                      </div>
                    </div>
                  );
                })}
              </div>
            </section>
          ))}
        </div>
      )}
    </div>
  );
};
