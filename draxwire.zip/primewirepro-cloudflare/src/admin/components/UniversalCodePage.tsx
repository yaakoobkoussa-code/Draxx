import React, { useCallback, useEffect, useState } from 'react';
import {
  Ban,
  CheckCircle2,
  Edit3,
  History,
  PauseCircle,
  Plus,
  Trash2,
} from 'lucide-react';
import { Modal } from '../../components/common/Modal';
import { ApiError, apiRequest } from '../../shared/api';
import { useToast } from '../../shared/ToastProvider';
import { formatDateTime, isoToLocalDatetimeInput } from '../../utils/formatters';
import { useAdminAuth } from '../hooks/useAdminAuth';

interface UniversalCodeRow {
  id: string;
  code: string;
  status: 'active' | 'suspended' | 'revoked' | 'expired';
  duration_seconds: number;
  usage_count: number;
  created_at: string;
  activated_at: string | null;
  expires_at: string;
  notes: string;
}

export const UniversalCodePage: React.FC = () => {
  const { can } = useAdminAuth();
  const { addToast } = useToast();

  const [codes, setCodes] = useState<UniversalCodeRow[]>([]);
  const [loading, setLoading] = useState(true);
  const [createOpen, setCreateOpen] = useState(false);
  const [editing, setEditing] = useState<UniversalCodeRow | null>(null);
  const [historyCode, setHistoryCode] = useState<UniversalCodeRow | null>(null);
  const [history, setHistory] = useState<
    { id: string; server_id: string; feature_id: string; status: string; created_at: string }[]
  >([]);

  const [codeInput, setCodeInput] = useState('');
  const [durationSeconds, setDurationSeconds] = useState(24 * 3600);
  const [customExpiresAt, setCustomExpiresAt] = useState('');
  const [notes, setNotes] = useState('');

  const load = useCallback(async () => {
    setLoading(true);
    try {
      const res = await apiRequest<{ codes: UniversalCodeRow[] }>(
        '/api/admin/universal-codes',
        { scope: 'admin' }
      );
      setCodes(res.codes);
    } catch (err) {
      addToast({
        type: 'error',
        title: 'Failed to load universal codes',
        description: err instanceof ApiError ? err.message : undefined,
      });
    } finally {
      setLoading(false);
    }
  }, [addToast]);

  useEffect(() => {
    load();
  }, [load]);

  const handleCreate = async (e: React.FormEvent) => {
    e.preventDefault();
    let customExpiresIso: string | null = null;
    if (customExpiresAt) {
      const parsedExp = new Date(customExpiresAt);
      if (Number.isNaN(parsedExp.getTime()) || parsedExp.getTime() <= Date.now()) {
        addToast({
          type: 'error',
          title: 'Invalid expiration date',
          description: 'Custom expiration must be set to a future date and time.',
        });
        return;
      }
      customExpiresIso = parsedExp.toISOString();
    }
    try {
      await apiRequest('/api/admin/universal-codes', {
        method: 'POST',
        scope: 'admin',
        body: {
          code: codeInput,
          durationSeconds,
          customExpiresAt: customExpiresIso,
          notes,
        },
      });
      addToast({ type: 'success', title: 'Universal public code created' });
      setCreateOpen(false);
      setCodeInput('');
      setCustomExpiresAt('');
      setNotes('');
      await load();
    } catch (err) {
      addToast({
        type: 'error',
        title: 'Failed to create universal code',
        description: err instanceof ApiError ? err.message : undefined,
      });
    }
  };

  const handleEditSave = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!editing) return;
    const parsedExp = new Date(editing.expires_at);
    if (Number.isNaN(parsedExp.getTime())) {
      addToast({ type: 'error', title: 'Invalid expiration date/time' });
      return;
    }
    try {
      await apiRequest(`/api/admin/universal-codes/${editing.id}`, {
        method: 'PATCH',
        scope: 'admin',
        body: {
          code: editing.code,
          expiresAt: parsedExp.toISOString(),
          notes: editing.notes,
        },
      });
      addToast({ type: 'success', title: 'Universal code updated' });
      setEditing(null);
      await load();
    } catch (err) {
      addToast({
        type: 'error',
        title: 'Update failed',
        description: err instanceof ApiError ? err.message : undefined,
      });
    }
  };

  const updateStatus = async (id: string, status: 'active' | 'suspended' | 'revoked') => {
    try {
      await apiRequest(`/api/admin/universal-codes/${id}`, {
        method: 'PATCH',
        scope: 'admin',
        body: { status },
      });
      addToast({ type: 'success', title: `Universal code ${status}` });
      await load();
    } catch (err) {
      addToast({
        type: 'error',
        title: 'Action failed',
        description: err instanceof ApiError ? err.message : undefined,
      });
    }
  };

  const removeCode = async (id: string) => {
    try {
      await apiRequest(`/api/admin/universal-codes/${id}`, {
        method: 'DELETE',
        scope: 'admin',
      });
      addToast({ type: 'info', title: 'Universal code deleted' });
      await load();
    } catch (err) {
      addToast({
        type: 'error',
        title: 'Delete failed',
        description: err instanceof ApiError ? err.message : undefined,
      });
    }
  };

  const openHistory = async (row: UniversalCodeRow) => {
    setHistoryCode(row);
    try {
      const res = await apiRequest<{
        history: {
          id: string;
          server_id: string;
          feature_id: string;
          status: string;
          created_at: string;
        }[];
      }>(`/api/admin/universal-codes/${row.id}/history`, { scope: 'admin' });
      setHistory(res.history);
    } catch {
      setHistory([]);
    }
  };

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row sm:items-end justify-between gap-4">
        <div>
          <h1 className="font-display text-2xl font-bold text-white">
            Universal Code Management
          </h1>
          <p className="text-sm text-zinc-400 mt-0.5">
            Shared public codes usable by multiple users without one-device restrictions.
          </p>
        </div>

        {can('universal.manage') && (
          <button
            type="button"
            onClick={() => setCreateOpen(true)}
            className="self-start sm:self-auto min-h-[42px] px-4 rounded-xl bg-blue-700 hover:bg-blue-600 text-xs font-semibold text-white inline-flex items-center gap-2 shadow-[0_0_18px_rgba(37,99,235,0.35)]"
          >
            <Plus className="w-4 h-4" />
            <span>Create Universal Code</span>
          </button>
        )}
      </div>

      {loading ? (
        <p className="text-sm text-zinc-400">Loading universal codes...</p>
      ) : codes.length === 0 ? (
        <div className="rounded-2xl bg-[#101015] border border-zinc-800 p-10 text-center">
          <p className="text-sm font-medium text-zinc-300">No universal public codes yet</p>
          <p className="text-xs text-zinc-500 mt-1">
            Create a shared public code to allow multi-user time-limited access.
          </p>
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {codes.map((c) => (
            <div
              key={c.id}
              className="rounded-2xl bg-[#101015] border border-zinc-800/90 p-5 space-y-4"
            >
              <div className="flex items-start justify-between gap-3">
                <div>
                  <p className="font-mono text-lg font-bold text-white">{c.code}</p>
                  <p className="text-xs text-zinc-400 mt-0.5">
                    Expires: <span className="tabular-nums">{formatDateTime(c.expires_at)}</span>
                  </p>
                </div>
                <span
                  className={`text-xs font-semibold capitalize ${
                    c.status === 'active'
                      ? 'text-emerald-400'
                      : c.status === 'suspended'
                      ? 'text-amber-400'
                      : 'text-rose-400'
                  }`}
                >
                  {c.status}
                </span>
              </div>

              <div className="grid grid-cols-2 gap-3 rounded-xl bg-[#07070A] border border-zinc-800/80 p-3 text-xs">
                <div>
                  <span className="text-zinc-500">Activations</span>
                  <p className="mt-1 font-mono font-semibold text-white tabular-nums">
                    {c.usage_count}
                  </p>
                </div>
                <div>
                  <span className="text-zinc-500">Last Activated</span>
                  <p className="mt-1 font-mono text-zinc-300 tabular-nums">
                    {c.activated_at ? formatDateTime(c.activated_at) : 'Unused'}
                  </p>
                </div>
              </div>

              <div className="flex flex-wrap items-center gap-2 pt-2 border-t border-zinc-800/70">
                <button
                  type="button"
                  onClick={() => openHistory(c)}
                  className="min-h-[36px] px-3 rounded-lg bg-white/5 hover:bg-white/10 text-xs text-zinc-200 inline-flex items-center gap-1.5"
                >
                  <History className="w-3.5 h-3.5 text-blue-400" />
                  <span>History</span>
                </button>
                {can('universal.manage') && (
                  <>
                    <button
                      type="button"
                      onClick={() => setEditing({ ...c })}
                      className="min-h-[36px] px-3 rounded-lg bg-white/5 hover:bg-white/10 text-xs text-zinc-200 inline-flex items-center gap-1.5"
                    >
                      <Edit3 className="w-3.5 h-3.5" />
                      <span>Edit</span>
                    </button>
                    {c.status !== 'active' ? (
                      <button
                        type="button"
                        onClick={() => updateStatus(c.id, 'active')}
                        className="min-h-[36px] px-3 rounded-lg bg-emerald-500/10 text-xs text-emerald-300 inline-flex items-center gap-1.5"
                      >
                        <CheckCircle2 className="w-3.5 h-3.5" />
                        <span>Activate</span>
                      </button>
                    ) : (
                      <button
                        type="button"
                        onClick={() => updateStatus(c.id, 'suspended')}
                        className="min-h-[36px] px-3 rounded-lg bg-amber-500/10 text-xs text-amber-300 inline-flex items-center gap-1.5"
                      >
                        <PauseCircle className="w-3.5 h-3.5" />
                        <span>Suspend</span>
                      </button>
                    )}
                    {c.status !== 'revoked' && (
                      <button
                        type="button"
                        onClick={() => updateStatus(c.id, 'revoked')}
                        className="min-h-[36px] px-3 rounded-lg bg-rose-500/10 text-xs text-rose-300 inline-flex items-center gap-1.5"
                      >
                        <Ban className="w-3.5 h-3.5" />
                        <span>Revoke</span>
                      </button>
                    )}
                    <button
                      type="button"
                      onClick={() => removeCode(c.id)}
                      className="min-h-[36px] px-3 rounded-lg bg-white/5 hover:bg-rose-500/15 text-xs text-zinc-400 hover:text-rose-300 ml-auto inline-flex items-center gap-1"
                    >
                      <Trash2 className="w-3.5 h-3.5" />
                    </button>
                  </>
                )}
              </div>
            </div>
          ))}
        </div>
      )}

      <Modal
        open={createOpen}
        onClose={() => setCreateOpen(false)}
        title="Create Universal Code"
        subtitle="Shared public access code without 1-device restriction"
      >
        <form onSubmit={handleCreate} className="space-y-4">
          <div>
            <label htmlFor="uc-code" className="block text-xs font-medium text-zinc-300 mb-1">
              Shared Code String (4–40 chars)
            </label>
            <input
              id="uc-code"
              required
              value={codeInput}
              onChange={(e) =>
                setCodeInput(e.target.value.toUpperCase().replace(/[^A-Z0-9_-]/g, ''))
              }
              placeholder="e.g. PUBLIC2026"
              className="w-full min-h-[44px] px-3 rounded-xl bg-[#07070A] border border-zinc-800 text-sm font-mono text-white"
            />
          </div>
          <div>
            <label htmlFor="uc-dur" className="block text-xs font-medium text-zinc-300 mb-1">
              Validity Duration
            </label>
            <select
              id="uc-dur"
              value={durationSeconds}
              onChange={(e) => setDurationSeconds(Number(e.target.value))}
              className="w-full min-h-[44px] px-3 rounded-xl bg-[#07070A] border border-zinc-800 text-sm text-white"
            >
              <option value={3600}>1 Hour</option>
              <option value={24 * 3600}>24 Hours</option>
              <option value={7 * 86400}>7 Days</option>
              <option value={30 * 86400}>30 Days</option>
            </select>
          </div>
          <div>
            <label htmlFor="uc-exp" className="block text-xs font-medium text-zinc-300 mb-1">
              Custom Expiration Date & Time (Optional)
            </label>
            <input
              id="uc-exp"
              type="datetime-local"
              value={customExpiresAt}
              onChange={(e) => setCustomExpiresAt(e.target.value)}
              className="w-full min-h-[44px] px-3 rounded-xl bg-[#07070A] border border-zinc-800 text-sm text-white"
            />
          </div>
          <div>
            <label htmlFor="uc-notes" className="block text-xs font-medium text-zinc-300 mb-1">
              Notes
            </label>
            <input
              id="uc-notes"
              value={notes}
              onChange={(e) => setNotes(e.target.value)}
              placeholder="Event or public release label"
              className="w-full min-h-[44px] px-3 rounded-xl bg-[#07070A] border border-zinc-800 text-sm text-white"
            />
          </div>
          <div className="flex justify-end gap-2 pt-2">
            <button
              type="button"
              onClick={() => setCreateOpen(false)}
              className="min-h-[42px] px-4 rounded-xl bg-white/5 text-xs font-medium text-zinc-300"
            >
              Cancel
            </button>
            <button
              type="submit"
              className="min-h-[42px] px-5 rounded-xl bg-blue-700 hover:bg-blue-600 text-xs font-semibold text-white"
            >
              Create Code
            </button>
          </div>
        </form>
      </Modal>

      <Modal
        open={!!editing}
        onClose={() => setEditing(null)}
        title="Edit Universal Code"
        subtitle="Update code string or expiration timestamp"
      >
        {editing && (
          <form onSubmit={handleEditSave} className="space-y-4">
            <div>
              <label htmlFor="edit-uc" className="block text-xs font-medium text-zinc-300 mb-1">
                Code
              </label>
              <input
                id="edit-uc"
                required
                value={editing.code}
                onChange={(e) =>
                  setEditing({
                    ...editing,
                    code: e.target.value.toUpperCase().replace(/[^A-Z0-9_-]/g, ''),
                  })
                }
                className="w-full min-h-[44px] px-3 rounded-xl bg-[#07070A] border border-zinc-800 text-sm font-mono text-white"
              />
            </div>
            <div>
              <label htmlFor="edit-exp" className="block text-xs font-medium text-zinc-300 mb-1">
                Expiration Date &amp; Time
              </label>
              <input
                id="edit-exp"
                type="datetime-local"
                required
                value={isoToLocalDatetimeInput(editing.expires_at)}
                onChange={(e) => {
                  const val = e.target.value;
                  if (!val) return;
                  const dt = new Date(val);
                  if (!Number.isNaN(dt.getTime())) {
                    setEditing({ ...editing, expires_at: dt.toISOString() });
                  }
                }}
                className="w-full min-h-[44px] px-3 rounded-xl bg-[#07070A] border border-zinc-800 text-xs font-mono text-white"
              />
              <div className="flex flex-wrap gap-1.5 mt-2">
                {[
                  { label: '+1h', sec: 3600 },
                  { label: '+24h', sec: 86400 },
                  { label: '+7d', sec: 7 * 86400 },
                  { label: '+30d', sec: 30 * 86400 },
                ].map((preset) => (
                  <button
                    key={preset.label}
                    type="button"
                    onClick={() =>
                      setEditing({
                        ...editing,
                        expires_at: new Date(Date.now() + preset.sec * 1000).toISOString(),
                      })
                    }
                    className="min-h-[30px] px-2.5 rounded-lg bg-white/5 hover:bg-blue-500/15 border border-zinc-800 text-[11px] font-mono text-zinc-300"
                  >
                    Set {preset.label}
                  </button>
                ))}
              </div>
            </div>
            <div>
              <label htmlFor="edit-notes" className="block text-xs font-medium text-zinc-300 mb-1">
                Notes
              </label>
              <input
                id="edit-notes"
                value={editing.notes ?? ''}
                onChange={(e) => setEditing({ ...editing, notes: e.target.value })}
                placeholder="Optional label or notes"
                className="w-full min-h-[44px] px-3 rounded-xl bg-[#07070A] border border-zinc-800 text-sm text-white"
              />
            </div>
            <div className="flex justify-end gap-2 pt-2">
              <button
                type="button"
                onClick={() => setEditing(null)}
                className="min-h-[42px] px-4 rounded-xl bg-white/5 text-xs font-medium text-zinc-300"
              >
                Cancel
              </button>
              <button
                type="submit"
                className="min-h-[42px] px-5 rounded-xl bg-blue-700 hover:bg-blue-600 text-xs font-semibold text-white"
              >
                Save Changes
              </button>
            </div>
          </form>
        )}
      </Modal>

      <Modal
        open={!!historyCode}
        onClose={() => setHistoryCode(null)}
        title={`Activation History · ${historyCode?.code ?? ''}`}
      >
        {history.length === 0 ? (
          <p className="text-xs text-zinc-400 py-4 text-center">No subscription imports recorded.</p>
        ) : (
          <div className="space-y-2 max-h-64 overflow-y-auto text-xs">
            {history.map((h) => (
              <div
                key={h.id}
                className="rounded-xl bg-[#07070A] border border-zinc-800 px-3.5 py-2.5 flex items-center justify-between"
              >
                <span className="text-zinc-200">
                  {h.server_id.toUpperCase()} · {h.feature_id.toUpperCase()} ({h.status})
                </span>
                <span className="font-mono text-zinc-500 tabular-nums">
                  {formatDateTime(h.created_at)}
                </span>
              </div>
            ))}
          </div>
        )}
      </Modal>
    </div>
  );
};
