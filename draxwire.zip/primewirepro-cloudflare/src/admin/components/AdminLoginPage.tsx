import React, { useState } from 'react';
import { motion } from 'motion/react';
import {
  AlertCircle,
  Database,
  Eye,
  EyeOff,
  Loader2,
  Lock,
  Mail,
  ShieldCheck,
} from 'lucide-react';
import { BrandLogo } from '../../components/common/BrandLogo';
import { useAdminAuth } from '../hooks/useAdminAuth';

export const AdminLoginPage: React.FC = () => {
  const { needsBootstrap, autoVaultMeta, login } = useAdminAuth();

  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [showPassword, setShowPassword] = useState(false);

  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const handleLogin = async (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);
    setLoading(true);
    const res = await login(email.trim(), password);
    setLoading(false);
    if (!res.ok && res.error) setError(res.error);
  };

  const hasSavedVault =
    autoVaultMeta &&
    (autoVaultMeta.keysCount > 0 ||
      autoVaultMeta.universalCount > 0 ||
      autoVaultMeta.urlsCount > 0 ||
      autoVaultMeta.maintenanceMode);

  return (
    <div className="min-h-screen bg-[#07070A] text-zinc-100 flex flex-col justify-between px-4 py-6 pt-safe pb-safe">
      <div className="w-full max-w-5xl mx-auto flex items-center justify-between">
        <div className="flex items-center gap-2.5">
          <BrandLogo size="sm" glow={false} />
          <span className="font-display text-sm font-bold text-white">𝐃𝐑𝐀𝐗 𝐓𝐄𝐀𝐌</span>
        </div>
        <span className="text-xs font-mono text-zinc-500">Administration Dashboard</span>
      </div>

      <main className="w-full max-w-md mx-auto my-auto py-8">
        <motion.div
          initial={{ opacity: 0, y: 12 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.2 }}
          className="rounded-2xl bg-[#0C1120] border border-blue-500/25 p-6 sm:p-8 shadow-2xl shadow-black/80"
        >
          <div className="flex items-center gap-3.5">
            <BrandLogo size="md" glow />
            <div>
              <div className="flex items-center gap-1.5 text-xs font-medium text-blue-400">
                <ShieldCheck className="w-3.5 h-3.5" />
                <span>Restricted Access</span>
              </div>
              <h1 className="font-display text-xl font-bold text-white">Admin Sign In</h1>
            </div>
          </div>

          {hasSavedVault && (
            <div className="mt-4 rounded-xl bg-blue-950/35 border border-blue-500/35 px-3.5 py-2.5 text-xs text-blue-100 flex items-start gap-2.5">
              <Database className="w-4 h-4 text-blue-400 shrink-0 mt-0.5" />
              <div>
                <p className="font-semibold text-blue-200">Auto-Vault Protected</p>
                <p className="text-blue-200/80 mt-0.5">
                  {autoVaultMeta.keysCount} keys · {autoVaultMeta.universalCount} universal codes ·{' '}
                  {autoVaultMeta.urlsCount}/10 URLs will automatically restore on sign-in.
                </p>
              </div>
            </div>
          )}

          <form onSubmit={handleLogin} className="mt-5 space-y-4">
            <p className="text-xs text-zinc-400 leading-relaxed">
              {needsBootstrap
                ? 'First-time setup: enter your Gmail/email and a strong password (min 8 characters) to create your SUPER ADMIN account and sign in.'
                : 'Sign in with your administrator Gmail/email and password.'}
            </p>

            <div>
              <label htmlFor="adm-email" className="block text-xs font-medium text-zinc-300 mb-1.5">
                Email (Gmail)
              </label>
              <div className="relative flex items-center">
                <Mail className="w-4 h-4 text-zinc-500 absolute left-3.5 pointer-events-none" />
                <input
                  id="adm-email"
                  type="email"
                  required
                  autoComplete="email"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  placeholder="you@gmail.com"
                  className="w-full min-h-[46px] pl-10 pr-3 rounded-xl bg-[#07070A] border border-zinc-800 text-sm text-white placeholder:text-zinc-600 focus:outline-none focus:border-blue-500"
                />
              </div>
            </div>

            <div>
              <label htmlFor="adm-pw" className="block text-xs font-medium text-zinc-300 mb-1.5">
                Password
              </label>
              <div className="relative flex items-center">
                <Lock className="w-4 h-4 text-zinc-500 absolute left-3.5 pointer-events-none" />
                <input
                  id="adm-pw"
                  type={showPassword ? 'text' : 'password'}
                  required
                  autoComplete="current-password"
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  placeholder="Enter password"
                  className="w-full min-h-[46px] pl-10 pr-11 rounded-xl bg-[#07070A] border border-zinc-800 text-sm text-white placeholder:text-zinc-600 focus:outline-none focus:border-blue-500"
                />
                <button
                  type="button"
                  onClick={() => setShowPassword((prev) => !prev)}
                  aria-label={showPassword ? 'Hide password' : 'Show password'}
                  className="min-w-[36px] min-h-[36px] absolute right-1.5 flex items-center justify-center rounded-lg text-zinc-400 hover:text-zinc-200"
                >
                  {showPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                </button>
              </div>
            </div>

            {error && (
              <div
                role="alert"
                className="rounded-xl bg-rose-500/10 border border-rose-500/30 px-3.5 py-2.5 text-xs text-rose-200 flex items-start gap-2"
              >
                <AlertCircle className="w-4 h-4 text-rose-400 shrink-0 mt-0.5" />
                <span>{error}</span>
              </div>
            )}

            <button
              type="submit"
              disabled={loading}
              className="w-full min-h-[48px] rounded-xl bg-blue-700 hover:bg-blue-600 disabled:opacity-60 text-sm font-semibold text-white shadow-[0_0_24px_rgba(37,99,235,0.45)] flex items-center justify-center gap-2 transition-colors"
            >
              {loading ? (
                <>
                  <Loader2 className="w-4 h-4 animate-spin" />
                  <span>Authenticating...</span>
                </>
              ) : (
                <span>Sign In</span>
              )}
            </button>
          </form>
        </motion.div>
      </main>

      <footer className="w-full max-w-5xl mx-auto text-center text-xs text-zinc-600">
        𝐃𝐑𝐀𝐗 𝐓𝐄𝐀𝐌 Administration · Cloudflare Workers & D1
      </footer>
    </div>
  );
};
