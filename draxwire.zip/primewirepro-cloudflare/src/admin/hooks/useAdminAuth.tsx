import React, {
  createContext,
  useCallback,
  useContext,
  useEffect,
  useRef,
  useState,
} from 'react';
import {
  ApiError,
  apiRequest,
  getStoredAdminToken,
  setStoredAdminToken,
} from '../../shared/api';
import { useToast } from '../../shared/ToastProvider';
import { AdminUser } from '../../shared/types';

const AUTO_VAULT_LATEST_KEY = 'drax_admin_auto_snapshot_v2';
const AUTO_VAULT_PROTECTED_KEY = 'drax_admin_protected_vault_v2';
const LEGACY_VAULT_KEY = 'pmwr_admin_auto_snapshot_v1';
const IDB_NAME = 'drax_vault_db';
const IDB_STORE = 'vault';

export interface AdminBackupSnapshot {
  version?: number;
  exportedAt?: string;
  settings?: Record<string, any>;
  servers?: Record<string, any>[];
  features?: Record<string, any>[];
  subscriptionUrls?: Record<string, any>[];
  productKeys?: Record<string, any>[];
  universalCodes?: Record<string, any>[];
  registeredDevices?: Record<string, any>[];
  subscriptionTokens?: Record<string, any>[];
}

export interface AutoVaultMeta {
  savedAt: string;
  keysCount: number;
  universalCount: number;
  urlsCount: number;
  maintenanceMode: boolean;
}

const DEFAULT_TITLES = new Set(['PRIME WIRE PRO', '𝐃𝐑𝐀𝐗 𝐓𝐄𝐀𝐌', 'DRAX TEAM']);

function countConfiguredUrls(snap: AdminBackupSnapshot): number {
  return Array.isArray(snap.subscriptionUrls)
    ? snap.subscriptionUrls.filter((u) => Boolean(String(u.url ?? '').trim())).length
    : 0;
}

function computeVaultMeta(snap: AdminBackupSnapshot): AutoVaultMeta {
  return {
    savedAt: snap.exportedAt ?? new Date().toISOString(),
    keysCount: Array.isArray(snap.productKeys) ? snap.productKeys.length : 0,
    universalCount: Array.isArray(snap.universalCodes) ? snap.universalCodes.length : 0,
    urlsCount: countConfiguredUrls(snap),
    maintenanceMode: Boolean(snap.settings?.maintenance_mode),
  };
}

function snapshotHasCriticalData(snap: AdminBackupSnapshot): boolean {
  if ((snap.productKeys?.length ?? 0) > 0) return true;
  if ((snap.universalCodes?.length ?? 0) > 0) return true;
  if (countConfiguredUrls(snap) > 0) return true;
  if (Boolean(snap.settings?.maintenance_mode)) return true;
  if (Boolean(String(snap.settings?.announcement ?? '').trim())) return true;
  return false;
}

function snapshotHasUserData(snap: AdminBackupSnapshot): boolean {
  if (snapshotHasCriticalData(snap)) return true;
  const title = String(snap.settings?.website_title ?? '𝐃𝐑𝐀𝐗 𝐓𝐄𝐀𝐌').trim();
  if (title && !DEFAULT_TITLES.has(title)) return true;
  if ((snap.settings?.default_server_id ?? 'singapore') !== 'singapore') return true;
  if ((snap.servers ?? []).some((s) => Number(s.enabled) === 0 || s.status !== 'operational')) {
    return true;
  }
  if ((snap.features ?? []).some((f) => Number(f.enabled) === 0)) return true;
  return false;
}

function isServerEmptyData(current: AdminBackupSnapshot): boolean {
  return !snapshotHasCriticalData(current);
}

function openVaultDb(): Promise<IDBDatabase | null> {
  if (typeof indexedDB === 'undefined') return Promise.resolve(null);
  return new Promise((resolve) => {
    try {
      const req = indexedDB.open(IDB_NAME, 1);
      req.onupgradeneeded = () => {
        const db = req.result;
        if (!db.objectStoreNames.contains(IDB_STORE)) {
          db.createObjectStore(IDB_STORE);
        }
      };
      req.onsuccess = () => resolve(req.result);
      req.onerror = () => resolve(null);
    } catch {
      resolve(null);
    }
  });
}

async function idbRead(key: string): Promise<AdminBackupSnapshot | null> {
  const db = await openVaultDb();
  if (!db) return null;
  return new Promise((resolve) => {
    try {
      const tx = db.transaction(IDB_STORE, 'readonly');
      const store = tx.objectStore(IDB_STORE);
      const req = store.get(key);
      req.onsuccess = () => {
        const val = req.result as AdminBackupSnapshot | undefined;
        resolve(val && typeof val === 'object' ? val : null);
      };
      req.onerror = () => resolve(null);
      tx.oncomplete = () => db.close();
    } catch {
      resolve(null);
    }
  });
}

async function idbWrite(key: string, value: AdminBackupSnapshot | null): Promise<void> {
  const db = await openVaultDb();
  if (!db) return;
  await new Promise<void>((resolve) => {
    try {
      const tx = db.transaction(IDB_STORE, 'readwrite');
      const store = tx.objectStore(IDB_STORE);
      if (value === null) {
        store.delete(key);
      } else {
        store.put(value, key);
      }
      tx.oncomplete = () => {
        db.close();
        resolve();
      };
      tx.onerror = () => resolve();
    } catch {
      resolve();
    }
  });
}

function readLocalJson(storageKey: string): AdminBackupSnapshot | null {
  try {
    const raw = localStorage.getItem(storageKey);
    if (!raw) return null;
    const parsed = JSON.parse(raw) as AdminBackupSnapshot;
    return parsed && typeof parsed === 'object' ? parsed : null;
  } catch {
    return null;
  }
}

function readBestLocalSnapshot(): AdminBackupSnapshot | null {
  const protectedSnap = readLocalJson(AUTO_VAULT_PROTECTED_KEY);
  const latestSnap = readLocalJson(AUTO_VAULT_LATEST_KEY);
  const legacySnap = readLocalJson(LEGACY_VAULT_KEY);

  if (protectedSnap && snapshotHasUserData(protectedSnap)) return protectedSnap;
  if (latestSnap && snapshotHasUserData(latestSnap)) return latestSnap;
  if (legacySnap && snapshotHasUserData(legacySnap)) return legacySnap;
  return latestSnap ?? protectedSnap ?? legacySnap ?? null;
}

async function readBestStoredSnapshotAsync(): Promise<AdminBackupSnapshot | null> {
  const localBest = readBestLocalSnapshot();
  if (localBest && snapshotHasUserData(localBest)) return localBest;

  const idbProtected = await idbRead('protected');
  if (idbProtected && snapshotHasUserData(idbProtected)) {
    try {
      localStorage.setItem(AUTO_VAULT_PROTECTED_KEY, JSON.stringify(idbProtected));
    } catch {
      // Ignore quota error
    }
    return idbProtected;
  }

  const idbLatest = await idbRead('latest');
  if (idbLatest && snapshotHasUserData(idbLatest)) return idbLatest;

  return localBest ?? idbLatest ?? idbProtected ?? null;
}

function persistSnapshot(
  snap: AdminBackupSnapshot,
  allowClearProtected: boolean
): AutoVaultMeta | null {
  const hasUser = snapshotHasUserData(snap);
  const meta = computeVaultMeta(snap);

  if (!hasUser && !allowClearProtected) {
    // NEVER overwrite a populated protected vault with an empty reset server DB
    const existing = readBestLocalSnapshot();
    if (existing && snapshotHasUserData(existing)) {
      return computeVaultMeta(existing);
    }
  }

  try {
    localStorage.setItem(AUTO_VAULT_LATEST_KEY, JSON.stringify(snap));
    if (hasUser) {
      localStorage.setItem(AUTO_VAULT_PROTECTED_KEY, JSON.stringify(snap));
      localStorage.setItem(LEGACY_VAULT_KEY, JSON.stringify(snap));
    } else if (allowClearProtected) {
      localStorage.removeItem(AUTO_VAULT_PROTECTED_KEY);
      localStorage.removeItem(LEGACY_VAULT_KEY);
    }
  } catch {
    // Ignore storage quota errors, IDB will still retain copy
  }

  void idbWrite('latest', snap);
  if (hasUser) {
    void idbWrite('protected', snap);
  } else if (allowClearProtected) {
    void idbWrite('protected', null);
  }

  return meta;
}

interface AdminAuthContextValue {
  booting: boolean;
  needsBootstrap: boolean;
  admin: AdminUser | null;
  vaultVersion: number;
  autoVaultMeta: AutoVaultMeta | null;
  can: (permission: string) => boolean;
  login: (identifier: string, password: string) => Promise<{ ok: boolean; error?: string }>;
  bootstrapSuperAdmin: (input: {
    setupSecret: string;
    username: string;
    email: string;
    password: string;
  }) => Promise<{ ok: boolean; error?: string }>;
  logout: () => Promise<void>;
  refreshAdmin: () => Promise<void>;
  syncVaultNow: (silent?: boolean) => Promise<boolean>;
  restoreVaultNow: (silent?: boolean) => Promise<boolean>;
}

const AdminAuthContext = createContext<AdminAuthContextValue | null>(null);

export const AdminAuthProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const { addToast } = useToast();
  const [booting, setBooting] = useState(true);
  const [needsBootstrap, setNeedsBootstrap] = useState(false);
  const [admin, setAdmin] = useState<AdminUser | null>(null);
  const [vaultVersion, setVaultVersion] = useState(0);
  const [autoVaultMeta, setAutoVaultMeta] = useState<AutoVaultMeta | null>(() => {
    const snap = readBestLocalSnapshot();
    return snap ? computeVaultMeta(snap) : null;
  });

  const adminRef = useRef<AdminUser | null>(null);
  adminRef.current = admin;
  const vaultBusyRef = useRef(false);
  const intentionalClearRef = useRef(false);
  const sawNonEmptyServerRef = useRef(false);

  // Hydrate Auto-Vault metadata from IndexedDB backup if localStorage was wiped
  useEffect(() => {
    void (async () => {
      const snap = await readBestStoredSnapshotAsync();
      if (snap) {
        setAutoVaultMeta(computeVaultMeta(snap));
      }
    })();
  }, []);

  const syncOrAutoRestore = useCallback(
    async (activeAdmin: AdminUser) => {
      if (activeAdmin.roleId !== 'SUPER_ADMIN' || vaultBusyRef.current) return;
      vaultBusyRef.current = true;
      try {
        const current = await apiRequest<AdminBackupSnapshot>('/api/admin/backup?silent=1', {
          scope: 'admin',
        });
        const stored = await readBestStoredSnapshotAsync();

        if (stored && snapshotHasUserData(stored) && isServerEmptyData(current)) {
          await apiRequest('/api/admin/restore', {
            method: 'POST',
            scope: 'admin',
            body: stored,
          });
          const refreshed = await apiRequest<AdminBackupSnapshot>('/api/admin/backup?silent=1', {
            scope: 'admin',
          });
          sawNonEmptyServerRef.current = !isServerEmptyData(refreshed);
          const meta = persistSnapshot(refreshed, false);
          if (meta) setAutoVaultMeta(meta);
          setVaultVersion((v) => v + 1);
          addToast({
            type: 'success',
            title: 'Auto-Vault Restored',
            description:
              'All keys, universal codes, subscription URLs, and settings were automatically recovered.',
          });
          return;
        }

        if (!isServerEmptyData(current)) {
          sawNonEmptyServerRef.current = true;
        }
        const meta = persistSnapshot(current, false);
        if (meta) setAutoVaultMeta(meta);
      } catch {
        // Non-fatal background sync error
      } finally {
        vaultBusyRef.current = false;
      }
    },
    [addToast]
  );

  const syncVaultNow = useCallback(
    async (silent = false): Promise<boolean> => {
      if (adminRef.current?.roleId !== 'SUPER_ADMIN' || vaultBusyRef.current) return false;
      try {
        const snap = await apiRequest<AdminBackupSnapshot>(
          silent ? '/api/admin/backup?silent=1' : '/api/admin/backup',
          { scope: 'admin' }
        );

        const serverEmpty = isServerEmptyData(snap);
        if (serverEmpty && !intentionalClearRef.current) {
          // Server is empty unexpectedly (e.g. container restarted mid-session!)
          const stored = await readBestStoredSnapshotAsync();
          if (stored && snapshotHasUserData(stored)) {
            if (adminRef.current) {
              await syncOrAutoRestore(adminRef.current);
            }
            return true;
          }
        }

        const allowClear = intentionalClearRef.current && sawNonEmptyServerRef.current;
        if (!serverEmpty) {
          sawNonEmptyServerRef.current = true;
        }
        intentionalClearRef.current = false;

        const meta = persistSnapshot(snap, allowClear);
        if (meta) setAutoVaultMeta(meta);

        if (!silent) {
          addToast({
            type: 'success',
            title: 'Auto-Vault synced',
            description: `Saved ${meta?.keysCount ?? 0} keys and ${meta?.urlsCount ?? 0} URLs locally.`,
          });
        }
        return true;
      } catch (err) {
        if (!silent) {
          addToast({
            type: 'error',
            title: 'Auto-Vault sync failed',
            description: err instanceof ApiError ? err.message : undefined,
          });
        }
        return false;
      }
    },
    [addToast, syncOrAutoRestore]
  );

  const restoreVaultNow = useCallback(
    async (silent = false): Promise<boolean> => {
      if (adminRef.current?.roleId !== 'SUPER_ADMIN') return false;
      const stored = await readBestStoredSnapshotAsync();
      if (!stored) {
        if (!silent) {
          addToast({
            type: 'warning',
            title: 'No Auto-Vault snapshot found',
            description: 'Save keys or settings first so Auto-Vault has a snapshot.',
          });
        }
        return false;
      }
      try {
        await apiRequest('/api/admin/restore', {
          method: 'POST',
          scope: 'admin',
          body: stored,
        });
        const snap = await apiRequest<AdminBackupSnapshot>('/api/admin/backup?silent=1', {
          scope: 'admin',
        });
        sawNonEmptyServerRef.current = !isServerEmptyData(snap);
        const meta = persistSnapshot(snap, false);
        if (meta) setAutoVaultMeta(meta);
        setVaultVersion((v) => v + 1);
        if (!silent) {
          addToast({
            type: 'success',
            title: 'Auto-Vault restored',
            description: `Restored ${meta?.keysCount ?? 0} keys and ${meta?.urlsCount ?? 0} URLs.`,
          });
        }
        return true;
      } catch (err) {
        if (!silent) {
          addToast({
            type: 'error',
            title: 'Auto-Vault restore failed',
            description: err instanceof ApiError ? err.message : undefined,
          });
        }
        return false;
      }
    },
    [addToast]
  );

  const refreshAdmin = useCallback(async () => {
    try {
      const boot = await apiRequest<{ needsBootstrap: boolean }>('/api/admin/bootstrap-status');
      setNeedsBootstrap(boot.needsBootstrap);
      if (boot.needsBootstrap) {
        if (getStoredAdminToken()) {
          setStoredAdminToken(null);
        }
        setAdmin(null);
        return;
      }
    } catch {
      // Ignore transient bootstrap status check
    }

    try {
      const me = await apiRequest<{ admin: AdminUser }>('/api/admin/me', { scope: 'admin' });
      setAdmin(me.admin);
      await syncOrAutoRestore(me.admin);
    } catch (err) {
      setAdmin(null);
      if (err instanceof ApiError && err.status === 401 && getStoredAdminToken()) {
        setStoredAdminToken(null);
      }
    }
  }, [syncOrAutoRestore]);

  useEffect(() => {
    (async () => {
      await refreshAdmin();
      setBooting(false);
    })();
  }, [refreshAdmin]);

  // Keep Auto-Vault synchronized on admin mutations, tab hide, and periodic check
  useEffect(() => {
    if (!admin || admin.roleId !== 'SUPER_ADMIN') return;

    let debounceTimer: number | null = null;
    const onApiMutated = (event: Event) => {
      const detail = (event as CustomEvent<{ scope?: string; path?: string; method?: string }>).detail;
      if (!detail || detail.scope !== 'admin') return;
      const p = detail.path ?? '';
      if (
        p.startsWith('/api/admin/login') ||
        p.startsWith('/api/admin/logout') ||
        p.startsWith('/api/admin/restore')
      ) {
        return;
      }
      if (
        detail.method === 'DELETE' ||
        p.startsWith('/api/admin/subscription-urls/') ||
        p.startsWith('/api/admin/settings')
      ) {
        intentionalClearRef.current = true;
      }
      if (debounceTimer) window.clearTimeout(debounceTimer);
      debounceTimer = window.setTimeout(() => {
        void syncVaultNow(true);
      }, 220);
    };

    const onVisibility = () => {
      if (document.hidden) {
        void syncVaultNow(true);
      } else if (adminRef.current) {
        // When returning from idle/background tab, verify DB wasn't reset while sleeping
        void syncOrAutoRestore(adminRef.current);
      }
    };

    const onPageHide = () => {
      void syncVaultNow(true);
    };

    window.addEventListener('pmwr:api-mutated', onApiMutated);
    document.addEventListener('visibilitychange', onVisibility);
    window.addEventListener('pagehide', onPageHide);
    const interval = window.setInterval(() => {
      void syncVaultNow(true);
    }, 20_000);

    return () => {
      if (debounceTimer) window.clearTimeout(debounceTimer);
      window.removeEventListener('pmwr:api-mutated', onApiMutated);
      document.removeEventListener('visibilitychange', onVisibility);
      window.removeEventListener('pagehide', onPageHide);
      window.clearInterval(interval);
    };
  }, [admin, syncVaultNow, syncOrAutoRestore]);

  const can = useCallback(
    (permission: string) => {
      if (!admin) return false;
      return admin.roleId === 'SUPER_ADMIN' || admin.permissions.includes(permission);
    },
    [admin]
  );

  const login = useCallback(
    async (email: string, password: string) => {
      try {
        const res = await apiRequest<{
          ok: boolean;
          adminToken: string;
          admin: AdminUser;
        }>('/api/admin/login', {
          method: 'POST',
          body: { email: email.trim(), password },
        });
        setStoredAdminToken(res.adminToken);
        await refreshAdmin();
        addToast({ type: 'success', title: 'Administrator signed in' });
        return { ok: true };
      } catch (err) {
        return {
          ok: false,
          error: err instanceof ApiError ? err.message : 'Unable to sign in.',
        };
      }
    },
    [refreshAdmin, addToast]
  );

  const bootstrapSuperAdmin = useCallback(
    async (input: {
      setupSecret: string;
      username: string;
      email: string;
      password: string;
    }) => {
      try {
        await apiRequest('/api/admin/bootstrap', {
          method: 'POST',
          body: input,
        });
        addToast({
          type: 'success',
          title: 'SUPER ADMIN created',
          description: 'Sign in using your new administrator credentials.',
        });
        await refreshAdmin();
        return { ok: true };
      } catch (err) {
        return {
          ok: false,
          error: err instanceof ApiError ? err.message : 'Bootstrap failed.',
        };
      }
    },
    [refreshAdmin, addToast]
  );

  const logout = useCallback(async () => {
    await syncVaultNow(true);
    try {
      await apiRequest('/api/admin/logout', { method: 'POST', scope: 'admin' });
    } catch {
      // Ignore error
    }
    setStoredAdminToken(null);
    setAdmin(null);
    addToast({ type: 'info', title: 'Signed out of admin console' });
  }, [addToast, syncVaultNow]);

  return (
    <AdminAuthContext.Provider
      value={{
        booting,
        needsBootstrap,
        admin,
        vaultVersion,
        autoVaultMeta,
        can,
        login,
        bootstrapSuperAdmin,
        logout,
        refreshAdmin,
        syncVaultNow,
        restoreVaultNow,
      }}
    >
      {children}
    </AdminAuthContext.Provider>
  );
};

export function useAdminAuth() {
  const ctx = useContext(AdminAuthContext);
  if (!ctx) throw new Error('useAdminAuth must be used inside AdminAuthProvider');
  return ctx;
}
