import React, { useEffect, useState } from 'react';
import { AdminDashboard } from './components/admin/AdminDashboard';
import { AdminLoginPage } from './components/admin/AdminLoginPage';
import { AdminShell } from './components/admin/AdminShell';
import { DeviceProtection } from './components/admin/DeviceProtection';
import { DistributorManagement } from './components/admin/DistributorManagement';
import { FeaturePermissions } from './components/admin/FeaturePermissions';
import { KeyGenerator } from './components/admin/KeyGenerator';
import { KeyManagement } from './components/admin/KeyManagement';
import { SecurityLogs } from './components/admin/SecurityLogs';
import { ServerManagement } from './components/admin/ServerManagement';
import { SubscriptionUrlManagement } from './components/admin/SubscriptionUrlManagement';
import { WebsiteSettings } from './components/admin/WebsiteSettings';
import { LoadingScreen } from './components/common/LoadingScreen';
import { ToastContainer } from './components/common/ToastContainer';
import { AccountPage } from './components/user/AccountPage';
import { FeaturesPage } from './components/user/FeaturesPage';
import { HomeDashboard } from './components/user/HomeDashboard';
import { LoginPage } from './components/user/LoginPage';
import { ServerSelectionPage } from './components/user/ServerSelectionPage';
import { UserShell } from './components/user/UserShell';
import { AppStateProvider, useAppState } from './hooks/useAppState';
import { AdminSection, UserTab } from './types';

function isAdminPath(): boolean {
  if (typeof window === 'undefined') return false;
  return window.location.pathname.startsWith('/admin');
}

const AppRouter: React.FC = () => {
  const { userSession, isAdminAuthenticated, settings } = useAppState();
  const [booting, setBooting] = useState(true);
  const [inAdmin, setInAdmin] = useState<boolean>(isAdminPath);
  const [userTab, setUserTab] = useState<UserTab>('home');
  const [showServers, setShowServers] = useState(false);
  const [adminSection, setAdminSection] = useState<AdminSection>('dashboard');

  useEffect(() => {
    document.title = settings.websiteTitle || '𝐃𝐑𝐀𝐗 𝐓𝐄𝐀𝐌';
  }, [settings.websiteTitle]);

  useEffect(() => {
    const timer = window.setTimeout(() => setBooting(false), 450);
    return () => window.clearTimeout(timer);
  }, []);

  useEffect(() => {
    const handlePop = () => {
      setInAdmin(isAdminPath());
    };
    window.addEventListener('popstate', handlePop);
    return () => window.removeEventListener('popstate', handlePop);
  }, []);

  const navigateTo = (path: '/' | '/admin') => {
    if (window.location.pathname !== path) {
      window.history.pushState({}, '', path);
    }
    setInAdmin(path === '/admin');
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  if (booting) {
    return <LoadingScreen message="Initializing 𝐃𝐑𝐀𝐗 𝐓𝐄𝐀𝐌" />;
  }

  if (inAdmin) {
    if (!isAdminAuthenticated) {
      return <AdminLoginPage onBackToClient={() => navigateTo('/')} />;
    }

    const renderAdminSection = () => {
      switch (adminSection) {
        case 'dashboard':
          return <AdminDashboard onNavigateSection={setAdminSection} />;
        case 'key-generator':
          return <KeyGenerator />;
        case 'keys':
          return <KeyManagement />;
        case 'distributors':
          return <DistributorManagement />;
        case 'subscription-urls':
          return <SubscriptionUrlManagement />;
        case 'servers':
          return <ServerManagement />;
        case 'features':
          return <FeaturePermissions />;
        case 'device-protection':
          return <DeviceProtection />;
        case 'security-logs':
          return <SecurityLogs />;
        case 'settings':
          return <WebsiteSettings />;
        default:
          return <AdminDashboard onNavigateSection={setAdminSection} />;
      }
    };

    return (
      <AdminShell
        activeSection={adminSection}
        onSelectSection={setAdminSection}
        onBackToClient={() => navigateTo('/')}
      >
        {renderAdminSection()}
      </AdminShell>
    );
  }

  if (!userSession) {
    return <LoginPage onNavigateAdmin={() => navigateTo('/admin')} />;
  }

  const handleSelectTab = (tab: UserTab) => {
    setShowServers(false);
    setUserTab(tab);
  };

  return (
    <UserShell
      activeTab={userTab}
      onSelectTab={handleSelectTab}
      onNavigateAdmin={() => navigateTo('/admin')}
    >
      {showServers ? (
        <ServerSelectionPage onBack={() => setShowServers(false)} />
      ) : userTab === 'home' ? (
        <HomeDashboard
          onOpenServers={() => setShowServers(true)}
          onOpenFeatures={() => setUserTab('features')}
        />
      ) : userTab === 'features' ? (
        <FeaturesPage />
      ) : (
        <AccountPage />
      )}
    </UserShell>
  );
};

export default function App() {
  return (
    <AppStateProvider>
      <AppRouter />
      <ToastContainer />
    </AppStateProvider>
  );
}
