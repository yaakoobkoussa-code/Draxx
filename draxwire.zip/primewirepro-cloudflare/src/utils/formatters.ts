export const PRODUCT_KEY_REGEX = /^DRX-[A-Z0-9]{3}-[A-Z0-9]{3}$/;

export function formatProductKeyInput(raw: string): string {
  const cleaned = raw.toUpperCase().replace(/[^A-Z0-9]/g, '');
  if (!cleaned) return '';
  if (cleaned.length <= 3 && 'DRX'.startsWith(cleaned)) {
    return cleaned;
  }
  // Ensure DRX prefix if user starts typing raw characters or already typed DRX
  const body = cleaned.startsWith('DRX') ? cleaned.slice(3) : cleaned;
  const trimmed = body.slice(0, 6);
  const parts: string[] = [];
  for (let i = 0; i < trimmed.length; i += 3) {
    parts.push(trimmed.slice(i, i + 3));
  }
  return parts.length > 0 ? `DRX-${parts.join('-')}` : 'DRX-';
}

export function generateDemoProductKey(): string {
  const chars = 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789';
  const block = () =>
    Array.from({ length: 3 }, () => chars[Math.floor(Math.random() * chars.length)]).join('');
  return `DRX-${block()}-${block()}`;
}

export function maskProductKey(key: string): string {
  const segments = key.split('-');
  if (segments.length !== 3) return 'DRX-•••-•••';
  return `${segments[0]}-•••-${segments[2]}`;
}

export function formatDateShort(iso: string | null): string {
  if (!iso) return 'Pending activation';
  const date = new Date(iso);
  if (Number.isNaN(date.getTime())) return 'Invalid date';
  return date.toLocaleDateString('en-US', {
    month: 'short',
    day: 'numeric',
    year: 'numeric',
  });
}

export function formatDateTime(iso: string | null): string {
  if (!iso) return '—';
  const date = new Date(iso);
  if (Number.isNaN(date.getTime())) return '—';
  return date.toLocaleString('en-US', {
    month: 'short',
    day: 'numeric',
    hour: '2-digit',
    minute: '2-digit',
  });
}

export interface CountdownParts {
  days: number;
  hours: number;
  minutes: number;
  seconds: number;
  isExpired: boolean;
  progressPercent: number;
}

export function computeCountdown(expiresAtIso: string, activatedAtIso: string | null): CountdownParts {
  const now = Date.now();
  const end = new Date(expiresAtIso).getTime();
  const start = activatedAtIso ? new Date(activatedAtIso).getTime() : now - 86400000;
  const diff = Math.max(0, end - now);

  const totalSpan = Math.max(1, end - start);
  const progressPercent = Math.min(100, Math.max(0, Math.round((diff / totalSpan) * 100)));

  const days = Math.floor(diff / (1000 * 60 * 60 * 24));
  const hours = Math.floor((diff / (1000 * 60 * 60)) % 24);
  const minutes = Math.floor((diff / (1000 * 60)) % 60);
  const seconds = Math.floor((diff / 1000) % 60);

  return {
    days,
    hours,
    minutes,
    seconds,
    isExpired: diff <= 0,
    progressPercent,
  };
}

export function detectClientDeviceInfo(): { deviceLabel: string; platformName: string } {
  if (typeof navigator === 'undefined') {
    return { deviceLabel: 'Mobile Device', platformName: 'Web Client' };
  }
  const ua = navigator.userAgent;
  if (/iPhone/i.test(ua)) return { deviceLabel: 'iPhone Client', platformName: 'iOS Safari / PWA' };
  if (/iPad/i.test(ua)) return { deviceLabel: 'iPad Client', platformName: 'iPadOS' };
  if (/Android/i.test(ua)) return { deviceLabel: 'Android Device', platformName: 'Android Mobile' };
  if (/Macintosh/i.test(ua)) return { deviceLabel: 'Mac Workstation', platformName: 'macOS Browser' };
  if (/Windows/i.test(ua)) return { deviceLabel: 'Windows Desktop', platformName: 'Windows Browser' };
  return { deviceLabel: 'Desktop Client', platformName: 'Linux / Web' };
}

export function downloadCsv(filename: string, rows: Record<string, string | number | boolean>[]): void {
  if (rows.length === 0) return;
  const headers = Object.keys(rows[0]);
  const csvContent = [
    headers.join(','),
    ...rows.map((row) =>
      headers
        .map((h) => {
          const val = String(row[h] ?? '').replace(/"/g, '""');
          return `"${val}"`;
        })
        .join(',')
    ),
  ].join('\n');

  const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
  const url = URL.createObjectURL(blob);
  const link = document.createElement('a');
  link.href = url;
  link.download = filename;
  document.body.appendChild(link);
  link.click();
  document.body.removeChild(link);
  URL.revokeObjectURL(url);
}

export async function copyTextToClipboard(text: string): Promise<boolean> {
  try {
    if (typeof navigator !== 'undefined' && navigator.clipboard?.writeText) {
      await navigator.clipboard.writeText(text);
      return true;
    }
  } catch {
    // Fallback below
  }
  try {
    if (typeof document === 'undefined') return false;
    const ta = document.createElement('textarea');
    ta.value = text;
    ta.setAttribute('readonly', '');
    ta.style.position = 'fixed';
    ta.style.top = '-9999px';
    ta.style.opacity = '0';
    document.body.appendChild(ta);
    ta.select();
    ta.setSelectionRange(0, text.length);
    const ok = document.execCommand('copy');
    document.body.removeChild(ta);
    return ok;
  } catch {
    return false;
  }
}

export function isoToLocalDatetimeInput(iso: string | null | undefined): string {
  if (!iso) return '';
  const d = new Date(iso);
  if (Number.isNaN(d.getTime())) return '';
  const pad = (n: number) => String(n).padStart(2, '0');
  return `${d.getFullYear()}-${pad(d.getMonth() + 1)}-${pad(d.getDate())}T${pad(d.getHours())}:${pad(d.getMinutes())}`;
}
