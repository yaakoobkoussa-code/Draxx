#!/usr/bin/env bash
set -euo pipefail

# Automated Cloudflare Deployment Script for 𝐃𝐑𝐀𝐗 𝐓𝐄𝐀𝐌
# Target domains:
#   Public User Portal : https://client.draxwire.shop
#   Admin Dashboard    : https://admin.draxwire.shop
#   API Worker Routes  : client.draxwire.shop/api/* & admin.draxwire.shop/api/*

ROOT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
cd "$ROOT_DIR"

echo "=================================================="
echo "  DRAX TEAM — Cloudflare Deployment (draxwire.shop)"
echo "=================================================="

if ! command -v npx >/dev/null 2>&1; then
  echo "Error: Node.js / npx is required."
  exit 1
fi

echo "1/6 Checking Cloudflare authentication..."
npx wrangler whoami || npx wrangler login

echo "2/6 Ensuring D1 database (primewirepro-db) exists..."
D1_OUT=$(npx wrangler d1 create primewirepro-db 2>&1 || true)
echo "$D1_OUT"
DB_ID=$(echo "$D1_OUT" | grep -oE '[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}' | head -n 1 || true)

if [ -z "$DB_ID" ]; then
  DB_ID=$(npx wrangler d1 list 2>/dev/null | grep -A 2 "primewirepro-db" | grep -oE '[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}' | head -n 1 || true)
fi

if [ -n "$DB_ID" ]; then
  echo "Found D1 Database ID: $DB_ID"
  python3 -c '
import pathlib, re
p = pathlib.Path("workers/wrangler.toml")
txt = p.read_text()
txt = re.sub(r"database_id\s*=\s*\"[^\"]+\"", f"database_id = \"{__import__(\"sys\").argv[1]}\"", txt)
p.write_text(txt)
' "$DB_ID"
else
  echo "Warning: Could not auto-detect database_id. Ensure database_id is set in workers/wrangler.toml."
fi

echo "3/6 Applying D1 SQL migrations (0001, 0002, 0003)..."
(cd workers && npx wrangler d1 migrations apply DB --remote)

echo "4/6 Setting Worker secrets if not already configured..."
if [ -n "${BOOTSTRAP_ADMIN_EMAIL:-}" ] && [ -n "${BOOTSTRAP_ADMIN_PASSWORD:-}" ]; then
  SESSION_SEC="${SESSION_SECRET:-$(openssl rand -hex 32)}"
  printf "%s" "$SESSION_SEC" | (cd workers && npx wrangler secret put SESSION_SECRET)
  printf "%s" "$BOOTSTRAP_ADMIN_EMAIL" | (cd workers && npx wrangler secret put BOOTSTRAP_ADMIN_EMAIL)
  printf "%s" "$BOOTSTRAP_ADMIN_PASSWORD" | (cd workers && npx wrangler secret put BOOTSTRAP_ADMIN_PASSWORD)
else
  echo "Tip: Run these commands manually inside workers/ if not set yet:"
  echo "  npx wrangler secret put SESSION_SECRET"
  echo "  npx wrangler secret put BOOTSTRAP_ADMIN_EMAIL"
  echo "  npx wrangler secret put BOOTSTRAP_ADMIN_PASSWORD"
fi

echo "5/6 Deploying Cloudflare Worker (primewirepro-api)..."
(cd workers && npx wrangler deploy)

echo "6/6 Building & deploying Public (client) and Admin Pages..."
npm install --no-audit --no-fund
VITE_API_BASE_URL="" npm run build:public
VITE_API_BASE_URL="" npm run build:admin

npx wrangler pages project create drax-client --production-branch=main >/dev/null 2>&1 || true
npx wrangler pages project create drax-admin --production-branch=main >/dev/null 2>&1 || true

npx wrangler pages deploy dist --project-name=drax-client --branch=main
npx wrangler pages deploy dist-admin --project-name=drax-admin --branch=main

echo ""
echo "=================================================="
echo "  DEPLOYMENT COMPLETE!"
echo "  Next in Cloudflare Dashboard (draxwire.shop):"
echo "  1. Pages -> drax-client -> Custom domains -> Add: client.draxwire.shop"
echo "  2. Pages -> drax-admin  -> Custom domains -> Add: admin.draxwire.shop"
echo "  3. Workers -> primewirepro-api -> Settings -> Triggers -> Routes:"
echo "     Add route: client.draxwire.shop/api/*"
echo "     Add route: admin.draxwire.shop/api/*"
echo "=================================================="
