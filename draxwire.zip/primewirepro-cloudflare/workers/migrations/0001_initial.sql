-- PRIME WIRE PRO — Phase 2 Cloudflare D1 Relational Schema & Initial Seed
-- All tables use strict foreign keys, check constraints, and parameterized queries.

PRAGMA foreign_keys = ON;

-- 1. Administrator Roles
CREATE TABLE IF NOT EXISTS administrator_roles (
  id TEXT PRIMARY KEY,
  name TEXT NOT NULL UNIQUE,
  description TEXT NOT NULL,
  rank INTEGER NOT NULL
);

-- 2. Permissions Catalog
CREATE TABLE IF NOT EXISTS permissions (
  id TEXT PRIMARY KEY,
  description TEXT NOT NULL
);

-- Role <-> Permission Mapping
CREATE TABLE IF NOT EXISTS role_permissions (
  role_id TEXT NOT NULL,
  permission_id TEXT NOT NULL,
  PRIMARY KEY (role_id, permission_id),
  FOREIGN KEY (role_id) REFERENCES administrator_roles(id) ON DELETE CASCADE,
  FOREIGN KEY (permission_id) REFERENCES permissions(id) ON DELETE CASCADE
);

-- 3. Administrators
CREATE TABLE IF NOT EXISTS administrators (
  id TEXT PRIMARY KEY,
  username TEXT NOT NULL UNIQUE,
  email TEXT NOT NULL UNIQUE,
  password_hash TEXT NOT NULL,
  password_salt TEXT NOT NULL,
  role_id TEXT NOT NULL,
  custom_permissions_json TEXT NOT NULL DEFAULT '[]',
  status TEXT NOT NULL DEFAULT 'active' CHECK (status IN ('active', 'suspended')),
  created_at TEXT NOT NULL,
  updated_at TEXT NOT NULL,
  last_login_at TEXT,
  FOREIGN KEY (role_id) REFERENCES administrator_roles(id)
);

-- Admin Sessions
CREATE TABLE IF NOT EXISTS admin_sessions (
  id TEXT PRIMARY KEY,
  admin_id TEXT NOT NULL,
  token_hash TEXT NOT NULL UNIQUE,
  ip_hash TEXT NOT NULL,
  user_agent TEXT NOT NULL,
  created_at TEXT NOT NULL,
  expires_at TEXT NOT NULL,
  revoked_at TEXT,
  FOREIGN KEY (admin_id) REFERENCES administrators(id) ON DELETE CASCADE
);

-- 4. Servers (Exactly 5)
CREATE TABLE IF NOT EXISTS servers (
  id TEXT PRIMARY KEY CHECK (id IN ('brazil', 'india', 'singapore', 'europe', 'bangladesh')),
  name TEXT NOT NULL,
  flag TEXT NOT NULL,
  code TEXT NOT NULL UNIQUE,
  enabled INTEGER NOT NULL DEFAULT 1 CHECK (enabled IN (0, 1)),
  status TEXT NOT NULL DEFAULT 'operational' CHECK (status IN ('operational', 'high_load', 'maintenance')),
  routing_note TEXT NOT NULL DEFAULT '',
  sort_order INTEGER NOT NULL,
  updated_at TEXT NOT NULL
);

-- 5. Features (Exactly 2: AIM POINT & AIM POINT AND MOCO MARK)
CREATE TABLE IF NOT EXISTS features (
  id TEXT PRIMARY KEY CHECK (id IN ('aim_point', 'aim_point_moco_mark')),
  title TEXT NOT NULL,
  description TEXT NOT NULL,
  enabled INTEGER NOT NULL DEFAULT 1 CHECK (enabled IN (0, 1)),
  updated_at TEXT NOT NULL
);

-- 6. Subscription URLs (Exactly 10: 5 servers x 2 features, initially empty)
CREATE TABLE IF NOT EXISTS subscription_urls (
  id TEXT PRIMARY KEY,
  server_id TEXT NOT NULL,
  feature_id TEXT NOT NULL,
  url TEXT NOT NULL DEFAULT '',
  enabled INTEGER NOT NULL DEFAULT 0 CHECK (enabled IN (0, 1)),
  last_tested_at TEXT,
  last_test_status TEXT,
  updated_at TEXT NOT NULL,
  updated_by_admin_id TEXT,
  UNIQUE (server_id, feature_id),
  FOREIGN KEY (server_id) REFERENCES servers(id) ON DELETE CASCADE,
  FOREIGN KEY (feature_id) REFERENCES features(id) ON DELETE CASCADE
);

-- 7. Registered Devices (Server-issued device credential binding)
CREATE TABLE IF NOT EXISTS registered_devices (
  id TEXT PRIMARY KEY,
  device_token_hash TEXT NOT NULL UNIQUE,
  device_label TEXT NOT NULL,
  platform TEXT NOT NULL,
  user_agent TEXT NOT NULL,
  status TEXT NOT NULL DEFAULT 'trusted' CHECK (status IN ('trusted', 'blocked')),
  first_seen_at TEXT NOT NULL,
  last_seen_at TEXT NOT NULL
);

-- 8. Individual Product Keys (Permanent 1-device binding)
CREATE TABLE IF NOT EXISTS product_keys (
  id TEXT PRIMARY KEY,
  key_code TEXT NOT NULL UNIQUE,
  status TEXT NOT NULL DEFAULT 'active' CHECK (status IN ('active', 'suspended', 'revoked', 'expired')),
  duration_seconds INTEGER NOT NULL CHECK (duration_seconds > 0),
  custom_expires_at TEXT,
  allowed_servers_json TEXT NOT NULL DEFAULT '["brazil","india","singapore","europe","bangladesh"]',
  allowed_features_json TEXT NOT NULL DEFAULT '["aim_point","aim_point_moco_mark"]',
  bound_device_id TEXT,
  bound_at TEXT,
  created_by_admin_id TEXT,
  created_at TEXT NOT NULL,
  activated_at TEXT,
  expires_at TEXT,
  notes TEXT NOT NULL DEFAULT '',
  FOREIGN KEY (bound_device_id) REFERENCES registered_devices(id) ON DELETE SET NULL
);

-- 9. Universal Public Codes (Multi-user shared, no 1-device restriction)
CREATE TABLE IF NOT EXISTS universal_codes (
  id TEXT PRIMARY KEY,
  code TEXT NOT NULL UNIQUE,
  status TEXT NOT NULL DEFAULT 'active' CHECK (status IN ('active', 'suspended', 'revoked', 'expired')),
  duration_seconds INTEGER NOT NULL CHECK (duration_seconds > 0),
  custom_expires_at TEXT,
  allowed_servers_json TEXT NOT NULL DEFAULT '["brazil","india","singapore","europe","bangladesh"]',
  allowed_features_json TEXT NOT NULL DEFAULT '["aim_point","aim_point_moco_mark"]',
  usage_count INTEGER NOT NULL DEFAULT 0,
  created_by_admin_id TEXT,
  created_at TEXT NOT NULL,
  activated_at TEXT,
  expires_at TEXT NOT NULL,
  notes TEXT NOT NULL DEFAULT ''
);

-- 10. Users (Client user accounts tied to activation credentials)
CREATE TABLE IF NOT EXISTS users (
  id TEXT PRIMARY KEY,
  auth_type TEXT NOT NULL CHECK (auth_type IN ('product_key', 'universal_code')),
  product_key_id TEXT,
  universal_code_id TEXT,
  device_id TEXT NOT NULL,
  created_at TEXT NOT NULL,
  last_login_at TEXT NOT NULL,
  FOREIGN KEY (product_key_id) REFERENCES product_keys(id) ON DELETE CASCADE,
  FOREIGN KEY (universal_code_id) REFERENCES universal_codes(id) ON DELETE CASCADE,
  FOREIGN KEY (device_id) REFERENCES registered_devices(id) ON DELETE CASCADE
);

-- 11. User Sessions
CREATE TABLE IF NOT EXISTS user_sessions (
  id TEXT PRIMARY KEY,
  user_id TEXT NOT NULL,
  auth_type TEXT NOT NULL CHECK (auth_type IN ('product_key', 'universal_code')),
  product_key_id TEXT,
  universal_code_id TEXT,
  device_id TEXT NOT NULL,
  token_hash TEXT NOT NULL UNIQUE,
  selected_server_id TEXT NOT NULL DEFAULT 'singapore',
  active_feature_id TEXT,
  created_at TEXT NOT NULL,
  expires_at TEXT NOT NULL,
  revoked_at TEXT,
  FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
  FOREIGN KEY (device_id) REFERENCES registered_devices(id) ON DELETE CASCADE,
  FOREIGN KEY (selected_server_id) REFERENCES servers(id),
  FOREIGN KEY (active_feature_id) REFERENCES features(id)
);

-- 12. Subscription Access Records (Audit trail for Happ imports & usage history)
CREATE TABLE IF NOT EXISTS subscription_access_records (
  id TEXT PRIMARY KEY,
  user_id TEXT NOT NULL,
  auth_type TEXT NOT NULL CHECK (auth_type IN ('product_key', 'universal_code')),
  credential_id TEXT NOT NULL,
  device_id TEXT NOT NULL,
  server_id TEXT NOT NULL,
  feature_id TEXT NOT NULL,
  status TEXT NOT NULL CHECK (status IN ('granted', 'denied', 'unavailable')),
  reason TEXT NOT NULL DEFAULT '',
  created_at TEXT NOT NULL
);

-- 13. Website Settings (Singleton row id = 1)
CREATE TABLE IF NOT EXISTS website_settings (
  id INTEGER PRIMARY KEY CHECK (id = 1),
  website_title TEXT NOT NULL DEFAULT '𝐃𝐑𝐀𝐗 𝐓𝐄𝐀𝐌',
  maintenance_mode INTEGER NOT NULL DEFAULT 0 CHECK (maintenance_mode IN (0, 1)),
  maintenance_message TEXT NOT NULL DEFAULT 'System maintenance is in progress. Please check back shortly.',
  announcement TEXT NOT NULL DEFAULT '',
  allow_admin_during_maintenance INTEGER NOT NULL DEFAULT 1 CHECK (allow_admin_during_maintenance IN (0, 1)),
  default_server_id TEXT NOT NULL DEFAULT 'singapore',
  updated_at TEXT NOT NULL,
  updated_by TEXT NOT NULL DEFAULT 'system'
);

-- 14. Security Logs (Append-only audit trail)
CREATE TABLE IF NOT EXISTS security_logs (
  id TEXT PRIMARY KEY,
  event_type TEXT NOT NULL,
  timestamp TEXT NOT NULL,
  actor_type TEXT NOT NULL,
  actor_id TEXT NOT NULL,
  actor_label TEXT NOT NULL,
  resource_type TEXT NOT NULL,
  resource_id TEXT NOT NULL,
  result TEXT NOT NULL CHECK (result IN ('success', 'denied', 'error')),
  details TEXT NOT NULL DEFAULT '',
  ip_hash TEXT NOT NULL DEFAULT ''
);

-- 15. Rate Limits (Brute-force & abuse protection)
CREATE TABLE IF NOT EXISTS rate_limits (
  bucket_key TEXT PRIMARY KEY,
  attempts INTEGER NOT NULL DEFAULT 0,
  window_start_ms INTEGER NOT NULL,
  blocked_until_ms INTEGER NOT NULL DEFAULT 0
);

-- 16. Code-Bound Subscription Tokens (Enforces key/code expiration on Happ subscription URLs)
CREATE TABLE IF NOT EXISTS subscription_tokens (
  id TEXT PRIMARY KEY,
  token_hash TEXT NOT NULL UNIQUE,
  auth_type TEXT NOT NULL CHECK (auth_type IN ('product_key', 'universal_code')),
  credential_id TEXT NOT NULL,
  device_id TEXT NOT NULL,
  server_id TEXT NOT NULL,
  feature_id TEXT NOT NULL,
  created_at TEXT NOT NULL,
  expires_at TEXT NOT NULL,
  last_fetched_at TEXT,
  fetch_count INTEGER NOT NULL DEFAULT 0,
  revoked_at TEXT
);

-- Indexes for fast queries
CREATE INDEX IF NOT EXISTS idx_product_keys_status ON product_keys(status);
CREATE INDEX IF NOT EXISTS idx_product_keys_bound_device ON product_keys(bound_device_id);
CREATE INDEX IF NOT EXISTS idx_universal_codes_code ON universal_codes(code);
CREATE INDEX IF NOT EXISTS idx_user_sessions_token ON user_sessions(token_hash);
CREATE INDEX IF NOT EXISTS idx_admin_sessions_token ON admin_sessions(token_hash);
CREATE INDEX IF NOT EXISTS idx_security_logs_ts ON security_logs(timestamp DESC);
CREATE INDEX IF NOT EXISTS idx_sub_access_cred ON subscription_access_records(credential_id, created_at DESC);
CREATE INDEX IF NOT EXISTS idx_sub_tokens_hash ON subscription_tokens(token_hash);
CREATE INDEX IF NOT EXISTS idx_sub_tokens_cred ON subscription_tokens(credential_id);

-- Seed Administrator Roles
INSERT OR IGNORE INTO administrator_roles (id, name, description, rank) VALUES
  ('SUPER_ADMIN', 'SUPER ADMIN', 'Full platform control including administrator creation and promotion', 100),
  ('ADMIN', 'ADMIN', 'Manage keys, universal codes, devices, servers, features, and URLs', 70),
  ('SUPPORT', 'SUPPORT', 'View keys/devices and perform manual device unbinding and key support', 40),
  ('VIEW_ONLY', 'VIEW ONLY', 'Read-only access to dashboards, keys, and audit logs', 10);

-- Seed Permissions
INSERT OR IGNORE INTO permissions (id, description) VALUES
  ('dashboard.view', 'View admin statistics and overview'),
  ('keys.view', 'View product keys and usage history'),
  ('keys.manage', 'Generate, suspend, reactivate, revoke, and delete product keys'),
  ('devices.view', 'View registered devices'),
  ('devices.unbind', 'Manually unbind or block registered devices'),
  ('universal.view', 'View universal public codes'),
  ('universal.manage', 'Create, edit, suspend, reactivate, and delete universal codes'),
  ('servers.manage', 'Manage regional servers'),
  ('features.manage', 'Manage feature permissions'),
  ('urls.manage', 'Manage and test the 10 private subscription URLs'),
  ('settings.manage', 'Manage website settings and maintenance mode'),
  ('logs.view', 'View security audit logs'),
  ('admins.manage', 'Create, edit, suspend, delete, and promote administrators (SUPER ADMIN only)');

-- Role -> Permissions Mapping
INSERT OR IGNORE INTO role_permissions (role_id, permission_id) VALUES
  ('SUPER_ADMIN', 'dashboard.view'), ('SUPER_ADMIN', 'keys.view'), ('SUPER_ADMIN', 'keys.manage'),
  ('SUPER_ADMIN', 'devices.view'), ('SUPER_ADMIN', 'devices.unbind'), ('SUPER_ADMIN', 'universal.view'),
  ('SUPER_ADMIN', 'universal.manage'), ('SUPER_ADMIN', 'servers.manage'), ('SUPER_ADMIN', 'features.manage'),
  ('SUPER_ADMIN', 'urls.manage'), ('SUPER_ADMIN', 'settings.manage'), ('SUPER_ADMIN', 'logs.view'),
  ('SUPER_ADMIN', 'admins.manage'),
  ('ADMIN', 'dashboard.view'), ('ADMIN', 'keys.view'), ('ADMIN', 'keys.manage'),
  ('ADMIN', 'devices.view'), ('ADMIN', 'devices.unbind'), ('ADMIN', 'universal.view'),
  ('ADMIN', 'universal.manage'), ('ADMIN', 'servers.manage'), ('ADMIN', 'features.manage'),
  ('ADMIN', 'urls.manage'), ('ADMIN', 'settings.manage'), ('ADMIN', 'logs.view'),
  ('SUPPORT', 'dashboard.view'), ('SUPPORT', 'keys.view'), ('SUPPORT', 'devices.view'),
  ('SUPPORT', 'devices.unbind'), ('SUPPORT', 'universal.view'), ('SUPPORT', 'logs.view'),
  ('VIEW_ONLY', 'dashboard.view'), ('VIEW_ONLY', 'keys.view'), ('VIEW_ONLY', 'devices.view'),
  ('VIEW_ONLY', 'universal.view'), ('VIEW_ONLY', 'logs.view');

-- Seed Exactly 5 Servers
INSERT OR IGNORE INTO servers (id, name, flag, code, enabled, status, routing_note, sort_order, updated_at) VALUES
  ('brazil', 'Brazil', '🇧🇷', 'BR-SAO', 1, 'operational', 'São Paulo regional edge relay', 1, datetime('now')),
  ('india', 'India', '🇮🇳', 'IN-BOM', 1, 'operational', 'Mumbai low-jitter relay', 2, datetime('now')),
  ('singapore', 'Singapore', '🇸🇬', 'SG-SIN', 1, 'operational', 'Southeast Asia core node', 3, datetime('now')),
  ('europe', 'Europe', '🇪🇺', 'EU-FRA', 1, 'operational', 'Frankfurt central gateway', 4, datetime('now')),
  ('bangladesh', 'Bangladesh', '🇧🇩', 'BD-DAC', 1, 'operational', 'Dhaka regional bridge', 5, datetime('now'));

-- Seed Exactly 2 Features
INSERT OR IGNORE INTO features (id, title, description, enabled, updated_at) VALUES
  ('aim_point', 'AIM POINT', 'Precision crosshair stabilization profile tuned for clean single-point target tracking.', 1, datetime('now')),
  ('aim_point_moco_mark', 'AIM POINT AND MOCO MARK', 'Combined target lock and Moco indicator relay profile. Mutually exclusive with Aim Point.', 1, datetime('now'));

-- Seed Exactly 10 Empty Subscription URLs (5 servers x 2 features) — NEVER fake URLs
INSERT OR IGNORE INTO subscription_urls (id, server_id, feature_id, url, enabled, updated_at) VALUES
  ('brazil__aim_point', 'brazil', 'aim_point', '', 0, datetime('now')),
  ('brazil__aim_point_moco_mark', 'brazil', 'aim_point_moco_mark', '', 0, datetime('now')),
  ('india__aim_point', 'india', 'aim_point', '', 0, datetime('now')),
  ('india__aim_point_moco_mark', 'india', 'aim_point_moco_mark', '', 0, datetime('now')),
  ('singapore__aim_point', 'singapore', 'aim_point', '', 0, datetime('now')),
  ('singapore__aim_point_moco_mark', 'singapore', 'aim_point_moco_mark', '', 0, datetime('now')),
  ('europe__aim_point', 'europe', 'aim_point', '', 0, datetime('now')),
  ('europe__aim_point_moco_mark', 'europe', 'aim_point_moco_mark', '', 0, datetime('now')),
  ('bangladesh__aim_point', 'bangladesh', 'aim_point', '', 0, datetime('now')),
  ('bangladesh__aim_point_moco_mark', 'bangladesh', 'aim_point_moco_mark', '', 0, datetime('now'));

-- Seed Singleton Website Settings
INSERT OR IGNORE INTO website_settings (
  id, website_title, maintenance_mode, maintenance_message, announcement, allow_admin_during_maintenance, default_server_id, updated_at, updated_by
) VALUES (
  1, '𝐃𝐑𝐀𝐗 𝐓𝐄𝐀𝐌', 0, 'System maintenance is currently underway. Access will resume shortly.', '', 1, 'singapore', datetime('now'), 'system'
);
