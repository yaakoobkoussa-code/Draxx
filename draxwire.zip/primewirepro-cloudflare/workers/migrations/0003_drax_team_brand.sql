-- Rebrand default website title to DRAX TEAM when still at initial system default
UPDATE website_settings
SET website_title = '𝐃𝐑𝐀𝐗 𝐓𝐄𝐀𝐌',
    updated_at = datetime('now')
WHERE id = 1
  AND website_title = 'PRIME WIRE PRO'
  AND updated_by = 'system';
