-- Migration 0002: Code-Bound Subscription Tokens for Time-Limited Happ Subscription Feeds
CREATE TABLE IF NOT EXISTS subscription_tokens (
  id TEXT PRIMARY KEY,
  token_hash TEXT NOT NULL UNIQUE,
  auth_type TEXT NOT NULL CHECK (auth_type IN ('product_key', 'universal_code')),
  credential_id TEXT NOT NULL,
  device_id TEXT NOT NULL,
  server_id TEXT NOT NULL,
  feature_id TEXT NOT NULL,
  created_at TEXT NOT NULL,
  expires_at TEXT NOT NULL,
  last_fetched_at TEXT,
  fetch_count INTEGER NOT NULL DEFAULT 0,
  revoked_at TEXT
);

CREATE INDEX IF NOT EXISTS idx_sub_tokens_hash ON subscription_tokens(token_hash);
CREATE INDEX IF NOT EXISTS idx_sub_tokens_cred ON subscription_tokens(credential_id);
