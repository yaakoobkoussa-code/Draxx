const encoder = new TextEncoder();

export function toHex(bytes: Uint8Array): string {
  return Array.from(bytes)
    .map((b) => b.toString(16).padStart(2, '0'))
    .join('');
}

export function fromHex(hex: string): Uint8Array {
  const clean = hex.trim();
  const out = new Uint8Array(clean.length / 2);
  for (let i = 0; i < out.length; i++) {
    out[i] = parseInt(clean.slice(i * 2, i * 2 + 2), 16);
  }
  return out;
}

export function randomHex(byteLength = 32): string {
  const bytes = new Uint8Array(byteLength);
  crypto.getRandomValues(bytes);
  return toHex(bytes);
}

export function randomId(prefix: string): string {
  return `${prefix}_${randomHex(12)}`;
}

export async function sha256Hex(input: string): Promise<string> {
  const digest = await crypto.subtle.digest('SHA-256', encoder.encode(input));
  return toHex(new Uint8Array(digest));
}

export function timingSafeEqualStr(a: string, b: string): boolean {
  if (a.length !== b.length) return false;
  let diff = 0;
  for (let i = 0; i < a.length; i++) {
    diff |= a.charCodeAt(i) ^ b.charCodeAt(i);
  }
  return diff === 0;
}

const PBKDF2_ITERATIONS = 100_000;

export async function hashPassword(
  password: string,
  saltHex?: string
): Promise<{ hashHex: string; saltHex: string }> {
  const salt = saltHex ? fromHex(saltHex) : crypto.getRandomValues(new Uint8Array(16));
  const usedSaltHex = saltHex ?? toHex(salt);
  const keyMaterial = await crypto.subtle.importKey(
    'raw',
    encoder.encode(password),
    'PBKDF2',
    false,
    ['deriveBits']
  );
  const derivedBits = await crypto.subtle.deriveBits(
    {
      name: 'PBKDF2',
      salt: salt.buffer as ArrayBuffer,
      iterations: PBKDF2_ITERATIONS,
      hash: 'SHA-256',
    },
    keyMaterial,
    256
  );
  return {
    hashHex: toHex(new Uint8Array(derivedBits)),
    saltHex: usedSaltHex,
  };
}

export async function verifyPassword(
  password: string,
  expectedHashHex: string,
  saltHex: string
): Promise<boolean> {
  const { hashHex } = await hashPassword(password, saltHex);
  return timingSafeEqualStr(hashHex, expectedHashHex);
}

async function importHmacKey(secret: string): Promise<CryptoKey> {
  return crypto.subtle.importKey(
    'raw',
    encoder.encode(secret),
    { name: 'HMAC', hash: 'SHA-256' },
    false,
    ['sign', 'verify']
  );
}

export async function signDeviceToken(deviceId: string, secret: string): Promise<string> {
  const nonce = randomHex(8);
  const payload = `${deviceId}.${nonce}`;
  const key = await importHmacKey(secret);
  const sig = await crypto.subtle.sign('HMAC', key, encoder.encode(payload));
  return `${payload}.${toHex(new Uint8Array(sig))}`;
}

export async function verifySignedDeviceToken(
  token: string,
  secret: string
): Promise<{ deviceId: string } | null> {
  const parts = token.split('.');
  if (parts.length !== 3) return null;
  const [deviceId, nonce, sigHex] = parts;
  if (!deviceId || !nonce || !sigHex || !/^[a-f0-9]+$/i.test(sigHex)) return null;
  const payload = `${deviceId}.${nonce}`;
  const key = await importHmacKey(secret);
  const expectedSig = await crypto.subtle.sign('HMAC', key, encoder.encode(payload));
  if (!timingSafeEqualStr(toHex(new Uint8Array(expectedSig)), sigHex.toLowerCase())) {
    return null;
  }
  return { deviceId };
}
