export interface D1PreparedStatement {
  bind(...values: unknown[]): D1PreparedStatement;
  first<T = Record<string, unknown>>(colName?: string): Promise<T | null>;
  run<T = unknown>(): Promise<{ success: boolean; meta: { changes?: number; last_row_id?: number } }>;
  all<T = Record<string, unknown>>(): Promise<{ results: T[]; success: boolean }>;
}

export interface D1Database {
  prepare(query: string): D1PreparedStatement;
  batch<T = unknown>(statements: D1PreparedStatement[]): Promise<T[]>;
  exec(query: string): Promise<unknown>;
}

export interface WorkerEnv {
  DB: D1Database;
  SESSION_SECRET: string;
  BOOTSTRAP_SETUP_SECRET?: string;
  BOOTSTRAP_ADMIN_USERNAME?: string;
  BOOTSTRAP_ADMIN_EMAIL?: string;
  BOOTSTRAP_ADMIN_PASSWORD?: string;
  PUBLIC_ORIGIN?: string;
  ADMIN_ORIGIN?: string;
  ALLOW_LOCAL_DEV_ORIGINS?: string;
}

export type AdminRoleId = 'SUPER_ADMIN' | 'ADMIN' | 'SUPPORT' | 'VIEW_ONLY';
export type ServerId = 'brazil' | 'india' | 'singapore' | 'europe' | 'bangladesh';
export type FeatureId = 'aim_point' | 'aim_point_moco_mark';
export type CredentialStatus = 'active' | 'suspended' | 'revoked' | 'expired';

export interface AdminRecord {
  id: string;
  username: string;
  email: string;
  password_hash: string;
  password_salt: string;
  role_id: AdminRoleId;
  custom_permissions_json: string;
  status: 'active' | 'suspended';
  created_at: string;
  updated_at: string;
  last_login_at: string | null;
}

export interface AuthenticatedAdmin {
  sessionId: string;
  id: string;
  username: string;
  email: string;
  roleId: AdminRoleId;
  permissions: string[];
}
