# دليل نشر 𝐃𝐑𝐀𝐗 𝐓𝐄𝐀𝐌 على Cloudflare لنطاق client.draxwire.shop

تم تجهيز هذه الحزمة لتعمل مباشرة مع نطاقك **`client.draxwire.shop`** (واجهة المستخدمين) و **`admin.draxwire.shop`** (لوحة المدير المنفصلة) على **Cloudflare Workers + D1 + Pages** مجاناً بالكامل:
- **الموقع العام للعملاء:** `https://client.draxwire.shop` (`prebuilt/public-pages/` أو `dist/`)
- **لوحة الإدارة المنفصلة:** `https://admin.draxwire.shop` (`prebuilt/admin-pages/` أو `dist-admin/`)
- **الخادم الخلفي API + اشتراكات Happ المشفرة:** Worker باسم `primewirepro-api` مربوط بمساري:
  - `client.draxwire.shop/api/*`
  - `admin.draxwire.shop/api/*`

> ميزة ربط Worker Routes على نفس الدومين (`client.draxwire.shop/api/*` و`admin.draxwire.shop/api/*`): لن تحتاج لتغيير أي عنوان API في البناء، والملفات المبنية مسبقاً في `prebuilt/` تعمل فوراً، وروابط اشتراكات Happ المشفرة تخرج باسم **`client.draxwire.shop`** بدون مشاكل CORS أو كوكيز على الآيفون والأندرويد.

---

## الطريقة الأسرع (من الكمبيوتر أو Termux بضغطة واحدة)

بعد فك الضغط وتشغيل الطرفية داخل المجلد:
```bash
chmod +x scripts/deploy-draxwire.sh
BOOTSTRAP_ADMIN_EMAIL="you@gmail.com" BOOTSTRAP_ADMIN_PASSWORD="StrongPassword#2026" bash scripts/deploy-draxwire.sh
```
ثم من لوحة Cloudflare على دومين `draxwire.shop`:
1. **Pages → `drax-client` → Custom domains** ← أضف `client.draxwire.shop`.
2. **Pages → `drax-admin` → Custom domains** ← أضف `admin.draxwire.shop`.
3. **Workers → `primewirepro-api` → Settings → Triggers → Routes** ← أضف المسارين:
   - `client.draxwire.shop/api/*` (Zone: `draxwire.shop`)
   - `admin.draxwire.shop/api/*` (Zone: `draxwire.shop`)

---

## الطريقة اليدوية من متصفح الهاتف (بدون أوامر نهائياً)

### 1. قاعدة بيانات Cloudflare D1
1. افتح [dash.cloudflare.com](https://dash.cloudflare.com) ← **Storage & Databases** → **D1 SQL Database** ← أنشئ قاعدة باسم **`primewirepro-db`**.
2. انسخ **Database ID** وضعه في ملف `workers/wrangler.toml` مكان `REPLACE_WITH_YOUR_D1_DATABASE_ID`.
3. افتح تبويب **Console** داخل `primewirepro-db` ونفّذ الملفات بالترتيب:
   - `workers/migrations/0001_initial.sql`
   - `workers/migrations/0002_subscription_tokens.sql`
   - `workers/migrations/0003_drax_team_brand.sql`

### 2. نشر Worker الخلفي (`primewirepro-api`)
1. ارفع المشروع إلى مستودع GitHub خاص (**Private Repo**) أو استخدم Wrangler.
2. من **Workers & Pages → Create → Import a repository**:
   - **Root directory:** `workers`
   - **Deploy command:** `npx wrangler deploy`
3. بعد النشر افتح `primewirepro-api` ← **Settings → Variables and Secrets**:
   - أضف متغيرات **Secret** التالية:
     - `SESSION_SECRET`: نص عشوائي بطول 64 حرفاً (مختلف).
     - `BOOTSTRAP_ADMIN_EMAIL`: بريدك للدخول إلى لوحة الإدارة.
     - `BOOTSTRAP_ADMIN_PASSWORD`: كلمة مرور قوية (8 أحرف فأكثر).
   - تأكد في **Variables** من القيم المضبوطة مسبقاً:
     - `PUBLIC_ORIGIN` = `https://client.draxwire.shop`
     - `ADMIN_ORIGIN` = `https://admin.draxwire.shop,https://client.draxwire.shop`
     - `ALLOW_LOCAL_DEV_ORIGINS` = `false`
   - تأكد تحت **Bindings** من ربط **D1 Database** باسم `DB` مع `primewirepro-db`.
4. من **Settings → Triggers → Routes** أضف المسارين على دومين `draxwire.shop`:
   - `client.draxwire.shop/api/*`
   - `admin.draxwire.shop/api/*`

### 3. رفع الواجهة العامة (`client.draxwire.shop`) ولوحة الإدارة (`admin.draxwire.shop`)
يمكنك رفع مجلدات **`prebuilt/`** الجاهزة مباشرة عبر **Upload assets** بدون بناء، أو ربط GitHub Pages:
- **المشروع 1 (العملاء):** `npm run build:public` (أو رفع مجلد `prebuilt/public-pages`) ← اربط **Custom Domain:** `client.draxwire.shop`.
- **المشروع 2 (المدير):** `npm run build:admin` (أو رفع مجلد `prebuilt/admin-pages`) ← اربط **Custom Domain:** `admin.draxwire.shop`.

### 4. تسجيل الدخول وإضافة روابط GitHub JSON
1. افتح **`https://admin.draxwire.shop`** وسجّل دخولك بـ Gmail وكلمة السر اللذين وضعتهما في Secrets.
2. افتح **Subscription URLs (10)** وضع روابط **GitHub JSON** لكل سيرفر وميزة واحفظ.
3. من **Key Management** أنشئ مفاتيح (مثل `1 Hour`)؛ عند فتح العميل **`https://client.draxwire.shop`** وضغط **ADD SUBSCRIPTION** سيفتح **Happ** تلقائياً باشتراك مشفّر `happ://crypt5/...` من نطاق **`client.draxwire.shop`** يتوقف بعد انتهاء المدة بالضبط!
