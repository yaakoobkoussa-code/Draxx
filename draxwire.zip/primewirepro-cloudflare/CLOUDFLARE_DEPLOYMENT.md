# PRIME WIRE PRO — Cloudflare Free Hosting Deployment Guide

This platform runs on **100% Cloudflare free-tier services** with zero purchased domains required:
1. **Cloudflare D1** — Relational SQLite database (`workers/migrations/0001_initial.sql`)
2. **Cloudflare Workers** — Protected REST API (`workers/api/src/index.ts`)
3. **Cloudflare Pages #1 (Public Website)** — User portal (`dist/` built via `npm run build:public`)
4. **Cloudflare Pages #2 (Admin Dashboard)** — Isolated administrator console (`dist-admin/` built via `npm run build:admin`)

---

## 1. Prerequisites

```bash
npm install
npm install -g wrangler
wrangler login
```

Verify authentication:
```bash
wrangler whoami
```

---

## 2. Create & Migrate Cloudflare D1 Database (Free Plan)

Create the database:
```bash
wrangler d1 create primewirepro-db
```

Copy the returned `database_id` into `workers/wrangler.toml`:
```toml
[[d1_databases]]
binding = "DB"
database_name = "primewirepro-db"
database_id = "<YOUR_D1_DATABASE_ID>"
migrations_dir = "migrations"
```

Apply all D1 schema migrations (`0001`, `0002`, `0003`):
```bash
cd workers
npx wrangler d1 migrations apply DB --remote
```

Confirm seeded tables:
```bash
npx wrangler d1 execute primewirepro-db --remote --command="SELECT id, name, enabled FROM servers;"
npx wrangler d1 execute primewirepro-db --remote --command="SELECT id, title, enabled FROM features;"
npx wrangler d1 execute primewirepro-db --remote --command="SELECT COUNT(*) AS url_slots FROM subscription_urls;"
```

---

## 3. Configure Secrets & Deploy the Backend API Worker (`draxwire.shop`)

Generate two strong random secrets:
```bash
openssl rand -hex 32   # SESSION_SECRET
openssl rand -hex 24   # BOOTSTRAP_SETUP_SECRET
```

Store them securely in Cloudflare Workers Secrets (never committed to Git):
```bash
cd workers
npx wrangler secret put SESSION_SECRET
npx wrangler secret put BOOTSTRAP_ADMIN_EMAIL
npx wrangler secret put BOOTSTRAP_ADMIN_PASSWORD
npx wrangler secret put BOOTSTRAP_SETUP_SECRET   # optional, only needed for curl/CLI bootstrap
```

`workers/wrangler.toml` is pre-configured for **`client.draxwire.shop`** and **`admin.draxwire.shop`**:
```toml
[vars]
PUBLIC_ORIGIN = "https://client.draxwire.shop"
ADMIN_ORIGIN = "https://admin.draxwire.shop,https://client.draxwire.shop"
ALLOW_LOCAL_DEV_ORIGINS = "false"
```

Deploy the Worker (and uncomment the `routes` block in `workers/wrangler.toml` or add routes in Cloudflare Dashboard → Triggers):
- `client.draxwire.shop/api/*` (zone: `draxwire.shop`)
- `admin.draxwire.shop/api/*` (zone: `draxwire.shop`)

```bash
cd workers
npx wrangler deploy
```

Verify health:
```bash
curl https://client.draxwire.shop/api/health
```

---

## 4. Deploy Separate Frontends (`client.draxwire.shop` & `admin.draxwire.shop`)

Or run the bundled automated script: `bash scripts/deploy-draxwire.sh`

### A. Build & Deploy Public Website (`dist/`) -> `client.draxwire.shop`
When Worker Routes (`client.draxwire.shop/api/*`) are attached on the same domain, leave `VITE_API_BASE_URL` empty (so `prebuilt/public-pages/` also works directly!):
```bash
npm run build:public
npx wrangler pages project create drax-client --production-branch=main
npx wrangler pages deploy dist --project-name=drax-client
```
Then add Custom Domain **`client.draxwire.shop`** under Cloudflare Pages → `drax-client` → Custom domains.

### B. Build & Deploy Separate Admin Dashboard (`dist-admin/`) -> `admin.draxwire.shop`
```bash
npm run build:admin
npx wrangler pages project create drax-admin --production-branch=main
npx wrangler pages deploy dist-admin --project-name=drax-admin
```
Then add Custom Domain **`admin.draxwire.shop`** under Cloudflare Pages → `drax-admin` → Custom domains.

Confirm strict separation: the `dist/` bundle contains zero admin components, zero `/api/admin` routes, and zero admin login forms.

---

## 5. Sign In as the Initial `SUPER_ADMIN` (Email + Password)

1. Open your deployed Admin Dashboard (`https://admin.draxwire.shop`).
2. Enter your Gmail/Email (`BOOTSTRAP_ADMIN_EMAIL`) and Password (`BOOTSTRAP_ADMIN_PASSWORD`) and click **Sign In** — on first login when `administrators` is empty, the Worker provisions your `SUPER_ADMIN` account in D1 and signs you in immediately.
3. As soon as the first `SUPER_ADMIN` exists, initial bootstrap provisioning permanently locks.
4. Open **Subscription URLs (10)** to add and enable your GitHub JSON or node URI endpoints, and use **Key Management** or **Universal Codes** to issue user access.

---

## 6. Cloudflare Free Plan Limits & Architecture Compatibility

| Service | Cloudflare Free Plan Limit | How PRIME WIRE PRO Fits Safely |
|---|---|---|
| **Cloudflare Pages** | Unlimited bandwidth, unlimited sites, 500 builds/month, 20,000 files/site | Two lightweight React/Vite SPAs (~10 files each) fit well within build and file quotas with zero bandwidth fees. |
| **Cloudflare Workers** | 100,000 requests/day, 10 ms CPU time per invocation | All auth/session checks use compact D1 indexed lookups and WebCrypto PBKDF2/HMAC (< 2–4 ms CPU). Periodic server polling is minimized. |
| **Cloudflare D1** | 5 GB storage, 5,000,000 rows read/day, 100,000 rows written/day | Indexed token hashes (`token_hash`, `key_code`) ensure single-row reads per API call; security logs & sessions fit comfortably under daily write quotas. |
| **Maintenance & Rate Limiting** | Stored in D1 (`website_settings`, `rate_limits`) | Requires zero paid Durable Objects or KV add-ons. |

### Optional Paid Upgrades Not Required
- No paid custom domain required (`.pages.dev` + `.workers.dev` provide automatic HTTPS TLS certificates).
- If future traffic exceeds **100,000 Worker requests/day** or **100,000 D1 writes/day**, upgrading to the **Workers Paid ($5/month)** tier immediately expands limits without code changes.

---

## 7. Security & Device Binding Notes

- **Permanent Device Binding (Web/PWA Browser Limitation):** Web browsers and PWAs cannot access hardware IMEI/Android ID directly. When a user activates an individual product key (`DRX-XXX-XXX`), the Worker issues an **HMAC-signed server device credential** stored in an `HttpOnly` cookie and `localStorage` (`X-Device-Token`). Another browser/phone without that credential is rejected (`403 DEVICE_MISMATCH`) unless an administrator manually runs **Unbind Device**. Note that if the original user wipes all browser storage/cookies, they will need an admin unbind to re-bind cleanly (which also prevents unauthorized sharing via browser clearing).
- **Private URL Protection:** Subscription URLs are stored exclusively in D1 and never included in public bundles or unauthenticated responses. Only authenticated, active, unbound-conflict-free, feature-permitted sessions receive a `happDeepLink` from `POST /api/subscription/resolve`.
